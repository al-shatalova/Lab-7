import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Students from './components/Students';
import Profile from './components/Profile';
import './App.css';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Students />} />
        <Route path="/profile/:studentId" element={<Profile />} />
      </Routes>
    </BrowserRouter>
  );
}
