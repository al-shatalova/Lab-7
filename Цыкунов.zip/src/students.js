export default [
  {
    id: '1',
    photo: 'https://sun6-22.userapi.com/s/v1/ig2/_yee4Kb2k2ATRKsGpa0LjsEg_cyCt_K3qNn_7LMbNerQ5bytLdCI9xrarmrQHWG50vTA0R6OFlp6otcPEIEMkcrb.jpg?size=1128x1129&quality=95&crop=276,0,1128,1129&ava=1',
    name: 'Керил Ерофеев',
    attendance: [1, 1, 1, 0, 1, 1, 1, 0],
  },
  {
    id: '2',
    photo: 'https://sun6-21.userapi.com/s/v1/ig1/mVFLPTwxGDxjEOzZLdqnIMAo8AVGgkPPuEPdVaNG0bQh_6vcdtQTAiDls7gZX2T25Oa_YO5e.jpg?size=1461x1461&quality=96&crop=368,1,1461,1461&ava=1',
    name: 'Мехаил Найденов',
    attendance: [1, 1, 0, 1, 1, 1, 1, 1],
  },
  {
    id: '3',
    photo: 'https://pp.userapi.com/c837621/v837621133/7df8/KckFue8RD0o.jpg',
    name: 'Цыкунов Максим',
    attendance: [1, 1, 1, 1, 1, 1, 1, 1],
  },
  {
    id: '4',
    photo: 'https://sun9-1.userapi.com/impf/yCZP7uO3FqfXb1deBhSO7xTSQbhyHqIlNny4gg/_I_sWuKjWPE.jpg?size=603x604&quality=96&sign=6e170fe9cdbf55579afff6f8e9875ff8&type=album',
    name: 'Дранекова Елена',
    attendance: [1, 1, 1, 0, 1, 0, 1, 1],
  },
  {
    id: '5',
    photo: 'https://vashezdorovie2019.ru/wp-content/uploads/2019/09/Fotolia_46660706_Subscription_Monthly_M-428x400.jpg',
    name: 'Трушкина Мория',
    attendance: [0, 1, 1, 0, 1, 1, 1, 1],
  },
  {
    id: '6',
    photo: 'https://getcollegeadmission.com/wp-content/uploads/2022/02/724-1-650x650.jpg',
    name: 'Вотютин Сергей',
    attendance: [1, 1, 0, 1, 1, 1, 0, 0],
  },
  {
    id: '7',
    photo: 'https://sun6-23.userapi.com/s/v1/if1/xdS1075qzc19vyJ0n7D0-fe9uc0XGmcH4z0P83vdl-hACbp5uZI04XSZq9xCMdg8iI7Azw.jpg?size=839x861&quality=96&crop=327,0,839,861&ava=1',
    name: 'Коржик Чувелев',
    attendance: [0, 1, 1, 0, 1, 1, 0, 1],
  },
  {
    id: '8',
    photo: 'https://sun1-95.userapi.com/s/v1/ig2/BdaFve-Dlc4eKJ_-jUq5CeN8rgIG6Nch5XM9MqHwTWi9o1Wgc9PsI7PRthtpbvMOwEU9LpdTzca_6QTPMKWfIUui.jpg?size=400x400&quality=96&crop=165,0,669,669&ava=1',
    name: 'Тетов Орсений',
    attendance: [0, 0, 1, 0, 0, 0, 0, 0],
  },
  {
    id: '9',
    photo: 'https://sun1-90.userapi.com/s/v1/ig2/nBVlzWhzxLpJCRzKCi8O5F7aY9MkSt7jWxgPDlvXlmvOavKP4YBJmhcJFY8cZa6E11D3lkr251kTdIBjzOSyHlrO.jpg?size=400x400&quality=95&crop=196,0,598,598&ava=1',
    name: 'Марухин Грегорий',
    attendance: [1, 0, 1, 0, 1, 0, 1, 1],
  },
  {
    id: '10',
    photo: 'https://i1.sndcdn.com/artworks-000407528727-geq9n1-t500x500.jpg',
    name: 'Петрук Мехаил',
    attendance: [1, 1, 1, 1, 1, 1, 1, 1],
  },
]