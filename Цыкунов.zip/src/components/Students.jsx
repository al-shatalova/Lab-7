import students from '../students';
import { Link } from 'react-router-dom';

export default function Students() {
  return (
    <section className="students-section">
      <div className="container">
        <h2>Группа ПИ21-5</h2>
        <div className="students-table">
          {students.map((student) => (
            <div key={student.id} className="row">
              <img src={student.photo} alt="" />
              <Link to={`/profile/${student.id}`}>{student.name}</Link>
              <div className="checkboxes">
                {student.attendance.map((lesson) => (
                  <input type="checkbox" key={student.id} checked={lesson} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
