import students from '../students';
import { useParams } from 'react-router-dom';

export default function Profile() {
  const { studentId } = useParams();
  const student = students.find((student) => student.id == studentId);

  return (
    <section className="student">
      <img src={student.photo} alt="" />
      {student.name}
      <div className="attendance">
        Посещаемость: {(student.attendance.filter(Boolean).length / student.attendance.length) * 100}%
      </div>
    </section>
  );
}
