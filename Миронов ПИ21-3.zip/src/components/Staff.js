// components/Staff.js
import React, { useState } from 'react';
import { Table, Form, Button } from 'react-bootstrap';

const Staff = () => {
  const [staff, setStaff] = useState([
    { name: 'Ахмад', surname: 'Авс', position: 'Преподаватель', achievements: 'Отпустил пораньше' },
    { name: 'Яна', surname: 'Богрова', position: 'Преподаватель', achievements: 'Защитила дисертацию' },
  ]);
  const [newStaff, setNewStaff] = useState({ name: '', surname: '', position: '', achievements: '' });
  const [search, setSearch] = useState('');

  const handleSearchChange = (e) => {
    const value = e.target.value.toLowerCase();
    setSearch(value);
    if (value) {
      setStaff(staff.filter(member =>
        member.name.toLowerCase().includes(value) ||
        member.surname.toLowerCase().includes(value) ||
        member.position.toLowerCase().includes(value) ||
        member.achievements.toLowerCase().includes(value)
      ));
    } else {
      setStaff(staff);
    }
  };

  const handleAddStaff = () => {
    if (newStaff.name && newStaff.surname && newStaff.position) {
      setStaff([...staff, newStaff]);
      setNewStaff({ name: '', surname: '', position: '', achievements: '' }); // Reset the form
    }
  };

  const handleDeleteStaff = (index) => {
    const updatedStaff = [...staff];
    updatedStaff.splice(index, 1);
    setStaff(updatedStaff);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewStaff({ ...newStaff, [name]: value });
  };

  return (
    <div>
      <Form>
        <Form.Group controlId="searchStaff">
          <Form.Label>Искать сотрудников:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите любой критерий"
            value={search}
            onChange={handleSearchChange}
          />
        </Form.Group>
      </Form>
        <br/>
      <Form>
        <Form.Group controlId="addStaffName">
          <Form.Label>Имя:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите имя"
            name="name"
            value={newStaff.name}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="addStaffSurname">
          <Form.Label>Фамилия:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите фамилию"
            name="surname"
            value={newStaff.surname}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="addStaffPosition">
          <Form.Label>Должность:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите должность"
            name="position"
            value={newStaff.position}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="addStaffAchievements">
          <Form.Label>Достижения:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите достижения"
            name="achievements"
            value={newStaff.achievements}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Button variant="primary" onClick={handleAddStaff}>
          Добавить сотрудника
        </Button>
      </Form>
        <br/>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Должность</th>
            <th>Достижения</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {staff.map((member, index) => (
            <tr key={index}>
              <td>{member.name}</td>
              <td>{member.surname}</td>
              <td>{member.position}</td>
              <td>{member.achievements}</td>
              <td>
                <Button variant="danger" onClick={() => handleDeleteStaff(index)}>
                  Удалить
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default Staff;
