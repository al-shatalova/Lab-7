// components/Marks.js
import React, { useState } from 'react';
import { Table, Form, Button } from 'react-bootstrap';

const Marks = () => {
  const [students, setStudents] = useState([
    { surname: 'Миронов', group: 'ПИ21-3', averageMark: 3.5 },
    { surname: 'Кувакин', group: 'Пи21-3', averageMark: 4.2 },
  ]);
  const [newStudent, setNewStudent] = useState({ surname: '', group: '', averageMark: '' });
  const [filter, setFilter] = useState('');

  const handleFilterChange = (e) => {
    const value = e.target.value;
    setFilter(value);
    if (value) {
      setStudents(students.filter(student => student.averageMark >= value));
    } else {
      setStudents(students);
    }
  };

  const handleAddStudent = () => {
    if (newStudent.surname && newStudent.group && newStudent.averageMark) {
      setStudents([...students, newStudent]);
      setNewStudent({ surname: '', group: '', averageMark: '' });
    }
  };

  const handleDeleteStudent = (index) => {
    const updatedStudents = [...students];
    updatedStudents.splice(index, 1);
    setStudents(updatedStudents);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewStudent({ ...newStudent, [name]: value });
  };

  return (
    <div>
      <Form>
        <Form.Group controlId="filterMarks">
          <Form.Label>Фильтр по минимальной средней оценке:</Form.Label>
          <Form.Control
            type="number"
            placeholder="Введите минимальную среднюю оценку"
            value={filter}
            onChange={handleFilterChange}
          />
        </Form.Group>
      </Form>
        <br/>
      <Form>
        <Form.Group controlId="addStudentSurname">
          <Form.Label>Фамилия:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите фамилию"
            name="surname"
            value={newStudent.surname}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="addStudentGroup">
          <Form.Label>Группа:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Введите группу"
            name="group"
            value={newStudent.group}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="addStudentAverageMark">
          <Form.Label>Средняя оценка:</Form.Label>
          <Form.Control
            type="number"
            placeholder="Введите среднюю оценку"
            name="averageMark"
            value={newStudent.averageMark}
            onChange={handleInputChange}
          />
        </Form.Group>
        <Button variant="primary" onClick={handleAddStudent}>
          Добавить студента
        </Button>
      </Form>
      <br/>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Фамилия</th>
            <th>Группа</th>
            <th>Средняя оценка</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.surname}</td>
              <td>{student.group}</td>
              <td>{student.averageMark}</td>
              <td>
                <Button variant="danger" onClick={() => handleDeleteStudent(index)}>
                  Удалить
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default Marks;
