// components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav } from 'react-bootstrap';

const NavigationBar = () => {
  return (
    <Navbar bg="light" expand="lg">
      <Navbar.Brand href="/">Электронный журнал</Navbar.Brand>
      <Nav className="mr-auto">
        <Nav.Link as={Link} to="/marks">Оценки</Nav.Link>
        <Nav.Link as={Link} to="/staff">Персонал</Nav.Link>
      </Nav>
    </Navbar>
  );
};

export default NavigationBar;
