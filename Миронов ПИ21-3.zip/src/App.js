import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Marks from './components/Marks';
import Staff from './components/Staff';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
          <Route exact path="/" element={<Marks/>} />
          <Route path="/marks" element={<Marks/>} />
          <Route path="/staff" element={<Staff/>} />
      </Routes>
    </Router>
  );
}

export default App;
