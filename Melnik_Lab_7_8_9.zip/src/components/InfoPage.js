import React from 'react';
import { Container, Typography, Box } from '@mui/material';

const InfoPage = () => {
    return (
        <Container maxWidth="sm" style={{ textAlign: 'center' }}>
            <Typography variant="h3" gutterBottom>
                Информация о сайте
            </Typography>

            <Box
                component="img"
                src="https://sun9-44.userapi.com/impg/J0KExFD_E1RMGG8P84aPwslyKsf7GUhhU-ymbA/TybzxOWcaoU.jpg?size=810x1080&quality=95&sign=59e4e526a0ae77e4428dc1617c2cf9c9&type=album"
                alt="Автор"
                sx={{ maxWidth: '200px', borderRadius: '10%', margin: 'auto' }}
            />

            <Typography variant="h4" gutterBottom>
                Об авторе
            </Typography>
            <Typography paragraph>
                Сайт был создан Мельником Геннадием за одну ночь и под кофе
            </Typography>

            <Typography variant="h4" gutterBottom>
                О работе
            </Typography>
            <Typography paragraph>
                Ну это типо три лабы в одной
            </Typography>

            <Typography paragraph>
                Тут надо Вставить текст для привлечения внимания
            </Typography>
        </Container>
    );
};

export default InfoPage;
