import React from 'react';
import { Box, Typography } from '@mui/material';

const Footer = () => {
    return (
        <Box component="footer" sx={{ bgcolor: 'background.paper', py: 6, mt: 'auto', textAlign: 'center' }}>
            <Typography variant="body1">
                &copy; 2023 Финансовый университет. Все права мои. Я тут царь.
            </Typography>
        </Box>
    );
}

export default Footer;
