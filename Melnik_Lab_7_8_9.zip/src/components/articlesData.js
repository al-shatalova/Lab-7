const articlesData = {
    ai: [
        {
            title: "Прорывы в области ии и чат-ботов",
            description: "Разбор феномена chatgpt.",
            imageUrl: "https://lovereport.ru/wp-content/uploads/2023/06/b2dcf1ad8cc46f860f6ec3c6fe1af09e.jpg"
        },
        {
            title: "Использование ии вместо операторов",
            description: "Как ии постепенно забирает рабочие места",
            imageUrl: "https://umihelp.com/source/news/blogimage69394.jpg"
        },
        {
            title: "Предвзятость ии в отношении отдельных 'наций' ",
            description: "Обсуждение вопросов связанных с предвязтостью ии по отношению ии к отдельным нациям.",
            imageUrl: "https://avatars.dzeninfra.ru/get-zen_doc/167204/pub_5c145b267abc1600aaad6ae4_5c145b316d68f700aa4590bd/scale_1200"
        }
    ],
    blockchain: [
        {
            title: "Блокчейн в банковской системе",
            description: "Разбор xpr/xrp",
            imageUrl: "https://tocrypto.ru/content/uploads/2023/10/blockchain.jpg"
        },
        {
            title: "Блокчейн в играх и игровой сфере",
            description: "Разбор почему nft это плохо",
            imageUrl: "https://tocrypto.ru/content/uploads/2023/10/blockchain.jpg"
        },
        {
            title: "Блокчейн и криптовалюты: состояние рынка",
            description: "Как бум майнинга перевернул рынок видеокарт",
            imageUrl: "https://cdto.wiki/images/7/76/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA_%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0_2020-08-21_%D0%B2_13.10.57.png"
        }
    ],
    webDev: [
        {
            title: "Новые фреймворки для веба",
            description: "Изучаем новые приколы 2023 года",
            imageUrl: "https://www.konstantinfo.com/blog/wp-content/uploads/2018/05/JavaScript-Frameworks.jpg"
        },
        {
            title: "Разработка адаптивного дизайна",
            description: "Разбор основ адаптивного дизайна",
            imageUrl: "https://seo-hi.ru/wp-content/uploads/2019/11/adaptivniy-lending.jpg"
        },
        {
            title: "Мультиплатформенная разработка",
            description: "Разбираем приципы мультиплатформы",
            imageUrl: "https://iwis.io/wp-content/uploads/2022/01/kmm-release-scheme_blogpost.jpg"
        }
    ],
    cyberSecurity: [
        {
            title: "Текущие угрозы от ddos",
            description: "Разбираемся, как защититься от ддос атаки",
            imageUrl: "https://content.kaspersky-labs.com/se/ru/content/ru-ru/images/enterprise/services/ddos-protection-2/ddos-protection-2.jpg"
        },
        {
            title: "Что делать в случаае деанона?dcv7",
            description: "Разбираем способы удаления нашего докса",
            imageUrl: "https://static12.tgcnt.ru/posts/_0/9f/9fa1b9a167b9efbc80d98b688a54072a.jpg"
        },
        {
            title: "Анонимность в интернете",
            description: "Как защитить себя и свои данные в интернете?",
            imageUrl: "https://hostingkartinok.com/news/wp-content/uploads/2019/06/Reshenie-zadachi-anonimnosti-v-seti.png"
        }
    ],
    edTech: [
        {
            title: "Эволюция дистанционного обучения",
            description: "Как онлайн-школы создали и развили этот формат",
            imageUrl: "https://ouzs.ru/upload/iblock/026/0262824cbf5ce81cee7235942c389ae5.jpg"
        },
        {
            title: "1",
            description: "1",
            imageUrl: "1"
        },
        {
            title: "1",
            description: "1",
            imageUrl: "1"
        }
    ]
};

export default articlesData;
