import React, { useState, useRef } from 'react';
import { Container, Typography, Button, Box } from '@mui/material';

const TomatoTimer = () => {
    const [time, setTime] = useState(1500);
    const intervalRef = useRef(null);

    const adjustTime = (minutes) => {
        setTime((prevTime) => Math.max(prevTime + minutes * 60, 0));
    };

    const startTimer = () => {
        if (intervalRef.current !== null) return;

        intervalRef.current = setInterval(() => {
            setTime((prevTime) => {
                if (prevTime <= 0) {
                    clearInterval(intervalRef.current);
                    intervalRef.current = null;
                    alert('Время вышло!');
                    return 1500;
                }
                return prevTime - 1;
            });
        }, 1000);
    };

    const stopTimer = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    };

    const resetTimer = () => {
        stopTimer();
        setTime(1500);
    };

    const formatTime = () => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    return (
        <Container maxWidth="xs" style={{ textAlign: 'center', marginTop: '3rem' }}>
            <Typography variant="h4" gutterBottom>
                Таймер
            </Typography>
            <Box mb={3} p={2} border={1} borderRadius={4}>
                Оставшееся время: {formatTime()}
            </Box>
            <Box>
                <Button variant="contained" color="success" onClick={startTimer} style={{ margin: '0.5rem' }}>
                    Старт
                </Button>
                <Button variant="contained" color="error" onClick={stopTimer} style={{ margin: '0.5rem' }}>
                    Стоп
                </Button>
                <Button variant="contained" color="primary" onClick={() => adjustTime(5)} style={{ margin: '0.5rem' }}>
                    +5 мин
                </Button>
                <Button variant="contained" color="warning" onClick={() => adjustTime(-5)} style={{ margin: '0.5rem' }}>
                    -5 мин
                </Button>
                <Button variant="contained" color="secondary" onClick={resetTimer} style={{ margin: '0.5rem' }}>
                    Сбросить
                </Button>
            </Box>
        </Container>
    );
};

export default TomatoTimer;
