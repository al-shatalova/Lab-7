import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Box } from '@mui/material';


const StartScreen = ({ onStart }) => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');

    const handleStart = () => {
        onStart(`${firstName} ${lastName}`);
    };

    return (
        <Container maxWidth="sm" style={{ marginTop: '5rem', textAlign: 'center' }}>
            <Typography variant="h4" gutterBottom>
                Проверьте свои знания!
            </Typography>
            <Typography variant="h6" gutterBottom>
                Введите свое имя и фамилию:
            </Typography>
            <Box mb={2}>
                <TextField
                    fullWidth
                    label="Имя"
                    variant="outlined"
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                />
            </Box>
            <Box mb={3}>
                <TextField
                    fullWidth
                    label="Фамилия"
                    variant="outlined"
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                />
            </Box>
            <Button variant="contained" color="primary" onClick={handleStart}>
                Начать
            </Button>
        </Container>
    );
};
const Quiz = ({ userName, onQuizEnd }) => {
    const questions = [
        {
            text: "Какая правильная команда для создания нового проекта React?",
            options: ["npm create-react-app", "npx create-react-app myReactApp", "npm create-react-app myReactApp", "npx create-react-app"],
            answer: 1
        },
        {
            text: "На что myReactApp ссылается следующая команда? npx create-react-app myReactApp",
            options: ["Каталог для создания нового приложения в", "Имя, которое должно использоваться для нового приложения", "Ссылка на существующее приложение", "Тип приложения для создания"],
            answer: 0
        },
        {
            text: "Какая команда используется для запуска локального сервера разработки React?",
            options: ["npm build", "npm run dev", "npm serve", "npm start"],
            answer: 3
        },
        {
            text: "Какой хук в React используется для управления состоянием компонента?",
            options: ["useReducer", "useState", "useEffect", "useContext"],
            answer: 1
        },
        {
            text: "Что делает React Router?",
            options: ["Помогает с управлением состоянием", "Управляет маршрутизацией в приложениях", "Оптимизирует производительность приложения", "Автоматически тестирует приложение"],
            answer: 1
        },
        {
            text: "Какой метод классового компонента вызывается при первом монтировании компонента?",
            options: ["componentDidMount", "componentWillMount", "render", "componentDidUpdate"],
            answer: 0
        },
        {
            text: "Для чего используется JSX в React?",
            options: ["Для написания стилей", "Для управления событиями", "Для написания разметки и логики компонентов", "Для оптимизации запросов к серверу"],
            answer: 2
        },
        {
            text: "Какой компонент используется для создания маршрута в React Router?",
            options: ["Router", "Route", "Switch", "Link"],
            answer: 1
        },
        {
            text: "Какой хук React позволяет выполнять побочные эффекты в функциональных компонентах?",
            options: ["useReducer", "useEffect", "useState", "useContext"],
            answer: 1
        },
        {
            text: "Какой из этих методов не является методом жизненного цикла React компонента?",
            options: ["componentDidMount", "componentShouldUpdate", "componentDidUpdate", "componentWillUnmount"],
            answer: 1
        }
    ];


    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [score, setScore] = useState(0);

    const handleOptionSelect = (index) => {
        setSelectedOption(index);
    };

    const handleSubmit = () => {
        if (selectedOption === questions[currentQuestionIndex].answer) {
            setScore(prevScore => prevScore + 1);
        }

        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prevIndex => prevIndex + 1);
            setSelectedOption(null);
        } else {
            setTimeout(() => onQuizEnd(score + (selectedOption === questions[currentQuestionIndex].answer ? 1 : 0)), 0);
        }
    };

    return (
        <Container maxWidth="sm" style={{ marginTop: '5rem' }}>
            <Typography variant="h4" gutterBottom>
                Квиз для {userName}
            </Typography>
            <Box>
                <Typography variant="h6" gutterBottom>
                    {questions[currentQuestionIndex].text}
                </Typography>
                <Box>
                    {questions[currentQuestionIndex].options.map((option, index) => (
                        <Button
                            key={index}
                            variant={selectedOption === index ? 'contained' : 'outlined'}
                            color="primary"
                            onClick={() => handleOptionSelect(index)}
                            fullWidth
                            style={{ marginBottom: '1rem' }}
                        >
                            {option}
                        </Button>
                    ))}
                </Box>
                <Button variant="contained" color="success" onClick={handleSubmit}>
                    Отправить
                </Button>
            </Box>
        </Container>
    );
};



const QuizApp = () => {
    const [userName, setUserName] = useState('');
    const [quizStarted, setQuizStarted] = useState(false);

    const startQuiz = (fullName) => {
        setUserName(fullName);
        setQuizStarted(true);
    };

    const handleQuizEnd = (score) => {
        alert(`Квиз завершен. Ваш счет: ${score}`);
        setQuizStarted(false);
    };

    return (
        <div>
            {!quizStarted ? (
                <StartScreen onStart={startQuiz} />
            ) : (
                <Quiz userName={userName} onQuizEnd={handleQuizEnd} />
            )}
        </div>
    );
};

export default QuizApp;
