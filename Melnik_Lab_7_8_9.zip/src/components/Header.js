import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, Link } from '@mui/material';

const Header = () => {
    return (
        <AppBar position="static">
            <Toolbar>
                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                    <Link component={RouterLink} to="/" color="inherit" underline="none">
                        ruz.fa.ru (ну типа) + Новости(8 лаба*ну мне передали так* + Квиз (9 лаба)
                    </Link>
                </Typography>
                <Button color="inherit" component={RouterLink} to="/students">
                    Список группы
                </Button>
                <Button color="inherit" component={RouterLink} to="/info">
                    Информация
                </Button>
                <Button color="inherit" component={RouterLink} to="/news">
                    Новости для айтишников
                </Button>
                <Button color="inherit" component={RouterLink} to="/quiz">
                    Квиз
                </Button>
            </Toolbar>
        </AppBar>
    );
}

export default Header;
