import React, { useRef } from 'react';
import articlesData from './articlesData';
import ArticleCard from '../components/ArticleCard';
import TomatoTimer from '../components/TomatoTimer';
import { Container, Button, Typography, Box } from '@mui/material';
import './ArticleCard.css';
const NewsPage = () => {
    const aiRef = useRef(null);
    const blockchainRef = useRef(null);
    const webDevRef = useRef(null);
    const cyberSecurityRef = useRef(null);
    const edTechRef = useRef(null);

    const scrollToRef = (ref) => {
        ref.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    return (
        <Container>
            <TomatoTimer />
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, my: 2 }}>
                <Button variant="contained" onClick={() => scrollToRef(aiRef)}>Искусственный интеллект</Button>
                <Button variant="contained" onClick={() => scrollToRef(blockchainRef)}>Блокчейн</Button>
                <Button variant="contained" onClick={() => scrollToRef(webDevRef)}>Веб-разработка</Button>
                <Button variant="contained" onClick={() => scrollToRef(cyberSecurityRef)}>Кибербезопасность</Button>
                <Button variant="contained" onClick={() => scrollToRef(edTechRef)}>Новые технологии в образовании</Button>
            </Box>

            <section ref={aiRef}>
                <Typography variant="h4" gutterBottom>Искусственный интеллект</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                    {articlesData.ai.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </Box>
            </section>

            <section ref={blockchainRef}>
                <Typography variant="h4" gutterBottom>Блокчейн</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                    {articlesData.blockchain.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </Box>
            </section>

            <section ref={webDevRef}>
                <Typography variant="h4" gutterBottom>Веб-разработка</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                    {articlesData.webDev.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </Box>
            </section>

            <section ref={cyberSecurityRef}>
                <Typography variant="h4" gutterBottom>Кибербезопасность</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                    {articlesData.cyberSecurity.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </Box>
            </section>

            <section ref={edTechRef}>
                <Typography variant="h4" gutterBottom>Информационные технологии в образовании</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                    {articlesData.edTech.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </Box>
            </section>
        </Container>
    );
};

export default NewsPage;
