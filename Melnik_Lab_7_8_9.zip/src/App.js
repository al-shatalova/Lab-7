// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import StudentsPage from './components/StudentsPage';
import StudentDetailPage from './components/StudentDetailPage';
import InfoPage from "./components/InfoPage";
import NewsPage from './components/NewsPage';
import QuizApp from './components/QuizApp';

const App = () => {
    return (
        <div className="d-flex flex-column min-vh-100">
            <Router>
                <Header />
                <div className="container mt-4 flex-grow-1">
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/students" element={<StudentsPage />} />
                        <Route path="/students/:id" element={<StudentDetailPage />} />
                        <Route path="/news" element={<NewsPage />} />
                        <Route path="/info" element={<InfoPage />} />
                        <Route path="/quiz" element={<QuizApp />} />
                    </Routes>
                </div>
                <Footer />
            </Router>
        </div>
    );
}

export default App;
