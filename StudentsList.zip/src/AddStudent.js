import React, {useContext, useState} from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

const AddStudent = ({ show, handleClose, onAdd }) => {
    const [newStudent, setNewStudent] = useState({fullname: '', group: '' , aver_mark: ''});

    const handleAddClick = () => {
        onAdd(newStudent);
        setNewStudent({fullname:'', group: '' , aver_mark: ''});
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Добавить студента</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group controlId="formSecondName">
                        <Form.Label>ФИО</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите ФИО"
                            value={newStudent.fullname}
                            onChange={(e) => setNewStudent({ ...newStudent, fullname: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group controlId="formGroup">
                        <Form.Label>Группа</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите группу"
                            value={newStudent.group}
                            onChange={(e) => setNewStudent({ ...newStudent, group: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group className={'py-2'} controlId="formAver_mark">
                        <Form.Label>Средний балл</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите средний балл"
                            value={newStudent.aver_mark}
                            onChange={(e) => setNewStudent({ ...newStudent, aver_mark: e.target.value })}
                        />
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button className={'btn btn-secondary'} variant="secondary" onClick={handleClose}>
                    Закрыть
                </Button>
                <Button className={'btn btn-success'} variant="primary" onClick={handleAddClick}>
                    Добавить
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default AddStudent;
