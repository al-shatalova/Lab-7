import React, {useContext, useState} from 'react';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Header';
import StudentsList from './StudentsList';
import LogoPage from './LogoPage'


const App = () => {
    const [students, setStudents] = useState([
        { id: 1, fullname:'Олейников Александр', group: 'ПИ21-3', aver_mark: 3.8},
        { id: 2, fullname:'Перов Андрей', group: 'ПИ21-3', aver_mark: 2 },
        { id: 3, fullname:'Кувакин Илья', group: 'ПИ21-2', aver_mark: 3.4 },
        { id: 4, fullname:'Донскова Грета', group: 'ПИ21-3', aver_mark: 5 },
        { id: 5, fullname:'Парамонов Денис', group: 'ПИ21-3', aver_mark: 4.8 },
    ]);

    const handleDelete = (studentId) => {
        setStudents(students.filter((student) => student.id !== studentId));
    };

    const handleAdd = (newStudent) => {
        setStudents([...students, { id: students.length + 1, ...newStudent }]);
    };

    return (
        <Router>
            <div>
                <Header />

                <Routes>
                    <Route
                        path="/"
                        element={<StudentsList students={students} onDelete={handleDelete} onAdd={handleAdd} />}
                    />
                    <Route path="/logo" element={<LogoPage />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
