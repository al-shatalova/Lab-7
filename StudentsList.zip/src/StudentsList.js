import React, {useContext, useState} from 'react';

import Button from "react-bootstrap/Button";
import AddStudent from "./AddStudent";

const StudentsList = ({ students, onDelete, onAdd }) => {

    const [showModal, setShowModal] = useState(false);
    const [groupFilter, setGroupFilter] = useState('');

    const handleShowModal = () => setShowModal(true);
    const handleCloseModal = () => setShowModal(false);

    const filteredStudents = students.filter((student) =>
        groupFilter ? student.group.includes(groupFilter) : true
    );

    return (
        <div className="p-3">
            <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                    <div className="mr-2 px-4">
                        <input
                            type="text"
                            placeholder="Группа"
                            value={groupFilter}
                            onChange={(e) => setGroupFilter(e.target.value)}
                            className="form-control"
                        />
                    </div>
            </div>

            <Button className={'btn btn-success'} variant="primary" onClick={handleShowModal}>
                Добавить
            </Button>

            </div>
            <table className="table">
                <thead className="thead-dark">
                <tr>
                    <th>ID</th>
                    <th style={{ textAlign: 'center' }}>ФИО</th>
                    <th>Группа</th>
                    <th style={{ textAlign: 'center' }}>Средний балл</th>
                    <th>Отчислить</th>
                </tr>
                </thead>
                <tbody>
                {filteredStudents.map((student) => (
                    <tr key={student.id}>
                        <td>{student.id}</td>
                        <td style={{ textAlign: 'center' }}>{student.fullname}</td>
                        <td>{student.group}</td>
                        <td style={{ textAlign: 'center' }}>{student.aver_mark}</td>
                        <td>
                            <button
                                className="btn"
                                onClick={() => onDelete(student.id)}
                            >
                                В корзину
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <AddStudent show={showModal} handleClose={handleCloseModal} onAdd={onAdd} />
        </div>
    );
};

export default StudentsList;
