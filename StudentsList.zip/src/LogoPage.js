import React, { useContext } from 'react';

const LogoPage = () => {
    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <div>
                <img src="/images/logo.jpg" alt="Логотип" />
            </div>
        </div>
    );
};

export default LogoPage;