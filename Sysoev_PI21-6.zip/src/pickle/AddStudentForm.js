import React, { useState } from "react";
import "./AddStudentForm.css";
const AddStudentForm = ({ onAdd }) => {
    const [name, setName] = useState("");

    const handleAdd = () => {
        if (name.trim() !== "") {
            onAdd({ id: Date.now(), name });
            setName("");
        }
    };

    return (
        <div>
            <h2>Добавть студента</h2>
            <input
                type="text"
                placeholder="Введите имя студента"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />
            <button onClick={handleAdd}>Добавть</button>
        </div>
    );
};

export default AddStudentForm;
