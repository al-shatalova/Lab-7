// StudentList.js
import React from "react";
import { format, addDays } from "date-fns";
import "./StudentList.css";

const StudentList = ({ students, onDelete, onMarkAttendance }) => {
    const startDate = new Date(); // Начнем с текущей даты
    const dateLabels = Array.from({ length: 30 }, (_, index) =>
        format(addDays(startDate, index), "dd.MM")
    );

    return (
        <div>
            <h2>Список Студентов</h2>
            <ul className="students-list">
                {students.map((student) => (
                    <li key={student.id}>
                        <span>{student.name}</span>
                        <div className="attendance-row">
                            {student.attendance.map((status, index) => (
                                <div key={index} className="day-attendance">
                                    <span>{dateLabels[index]}</span>
                                    <select
                                        value={status}
                                        onChange={(e) => onMarkAttendance(student.id, index, e.target.value === "true")}
                                    >
                                        <option value={true}>Был</option>
                                        <option value={false}>Отсутствовал</option>
                                    </select>
                                </div>
                            ))}
                        </div>
                        <button onClick={() => onDelete(student.id)}>Удалить</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudentList;
