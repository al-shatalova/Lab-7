// Home.js
import React, { useState, useEffect } from "react";
import StudentList from "../pickle/StudentList";
import AddStudentForm from "../pickle/AddStudentForm";
import "./home.css";

const Home = () => {
    const [students, setStudents] = useState([]);
    const [filteredStudents, setFilteredStudents] = useState([]);
    const [filter, setFilter] = useState("");

    useEffect(() => {
        const storedStudents = JSON.parse(localStorage.getItem("students")) || [];
        setStudents(storedStudents.map((student) => ({ ...student, attendance: generateAttendance() })));
        setFilteredStudents(storedStudents);
    }, []);

    useEffect(() => {
        const filtered = students.filter((student) =>
            student.name.toLowerCase().includes(filter.toLowerCase())
        );
        setFilteredStudents(filtered);
    }, [students, filter]);

    const handleAddStudent = (newStudent) => {
        const updatedStudents = [...students, { ...newStudent, attendance: generateAttendance() }];
        setStudents(updatedStudents);
        localStorage.setItem("students", JSON.stringify(updatedStudents));
    };

    const handleDeleteStudent = (id) => {
        const updatedStudents = students.filter((student) => student.id !== id);
        setStudents(updatedStudents);
        localStorage.setItem("students", JSON.stringify(updatedStudents));
    };

    const handleMarkAttendance = (studentId, dayIndex) => {
        const updatedStudents = students.map((student) => {
            if (student.id === studentId) {
                const updatedAttendance = [...student.attendance];
                updatedAttendance[dayIndex] = !updatedAttendance[dayIndex];
                return { ...student, attendance: updatedAttendance };
            }
            return student;
        });
        setStudents(updatedStudents);
        localStorage.setItem("students", JSON.stringify(updatedStudents));
    };

    const generateAttendance = () => {
        // Generate initial attendance for 30 days (true for present, false for absent)
        return new Array(30).fill(true);
    };

    return (
        <div>
            <h1>Журнал группы университета </h1>
            <AddStudentForm onAdd={handleAddStudent} />
            <input
                type="text"
                placeholder="Поиск по студентам"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
            />
            <StudentList
                students={filteredStudents}
                onDelete={handleDeleteStudent}
                onMarkAttendance={handleMarkAttendance}
            />
        </div>
    );
};

export default Home;
