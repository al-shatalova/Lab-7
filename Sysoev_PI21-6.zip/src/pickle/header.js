// Header.js
import React from "react";
import { Link } from "react-router-dom";
import logo from "../pickle/logo.png";

const Header = () => {
    return (
        <header style={{ backgroundColor: "#333", padding: "10px" }}>
            <nav>
                <img src={logo} alt="Logo" style={{ width: "100px", marginRight: "10px" }} />
                <ul>
                    <li>
                        <Link to="/">Домой</Link>
                    </li>
                    <li>
                        <Link to="/about">О нас</Link>
                    </li>
                    <li>
                        <Link to="/contact">Контакты</Link>
                    </li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;
