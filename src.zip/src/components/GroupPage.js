import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';


const attendanceOptions = ['+', 'Н', 'Б', 'ОП'];

function GroupPage() {
    const { groupId } = useParams();
    const [students, setStudents] = useState([
        { id: 1, name: 'Сунцов Андрей', group: 'ПИ21-2', attendance: {'2023-03-26': 'Б'}, grades: {'2023-03-12': 5, '2023-03-19': 5}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/66412/25001.281474976805991_optimized.jpg'},
        { id: 2, name: 'Исупова Дарья', group: 'ПИ21-2', attendance: {'2023-03-19': 'Н'}, grades: {'2023-03-12': 2}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67451/25001.281474976808490_optimized.jpg'},
        { id: 3, name: 'Преснухин Дмитрий', group: 'ПИ21-2', attendance: {}, grades: {}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/64951/25001.281474976809157_optimized.jpg'},
        { id: 4, name: 'Арясин Никита', group: 'ПИ21-2', attendance: {'2023-03-19': 'Н'}, grades: {}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/68973/25001.281474976809348_optimized.jpg'},
        { id: 5, name: 'Ойболатов Рамазан', group: 'ПИ21-2', attendance: {}, grades: {'2023-03-12': 5}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/70056/25001.281474976805566_optimized.jpg' },
        { id: 6, name: 'Журавлёва Анастасия', group: 'ПИ21-2', attendance: {'2023-03-19': 'ОП'}, grades: {'2023-03-19': 2}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67163/25001.281474976809979_optimized.jpg'},
        { id: 7, name: 'Огулова Евгения', group: 'ПИ21-1', attendance: {}, grades: {'2023-03-12': 1}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/70144/25001.281474976808029_optimized.jpg'},
        { id: 8, name: 'Битулёв Валерий', group: 'ПИ21-1', attendance: {'2023-03-19': 'ОП'}, grades: {}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/65008/25001.281474976806315_optimized.jpg'},
        { id: 9, name: 'Мерзлова Анастасия', group: 'ПИ21-1', attendance: {'2023-03-19': 'Н', '2023-03-12': 'ОП'}, grades: {'2023-03-12': 7}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67451/25001.281474976808490_optimized.jpg'},
        { id: 10, name: 'Пармёнова Дарья', group: 'ПИ21-1', attendance: {'2023-03-19': 'ОП'}, grades: {'2023-03-19': 8, '2023-03-26': 2}, photo: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67163/25001.281474976809979_optimized.jpg'},
        { id: 11, name: 'Косачёв Михаил', group: 'ПИ21-1', attendance: {'2023-03-19': 'ОП'}, grades: {'2023-03-12': 4}, photo:'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/64951/25001.281474976809157_optimized.jpg'},
    ]);

    const handleRemoveDate = (dateToRemove) => {
        const updatedDates = dates.filter((date) => date !== dateToRemove);
        setDates(updatedDates);
    };

    const handleToggleAttendance = (studentId, date, value) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === studentId
                    ? {
                        ...student,
                        attendance: {
                            ...student.attendance,
                            [date]: value,
                        },
                    }
                    : student
            )
        );
    };

    const handleSetGrade = (studentId, date, grade) => {
        if (/^\d*$/.test(grade) || grade === '') {
            setStudents((prevStudents) =>
                prevStudents.map((student) =>
                    student.id === studentId
                        ? {
                            ...student,
                            grades: {
                                ...student.grades,
                                [date]: grade,
                            },
                        }
                        : student
                )
            );
        }
    };

    const handleAddStudent = () => {
        const newStudent = {
            id: students.length + 1,
            name: 'Фамилия Имя',
            group: groupId,
            attendance: {},
            grades: {},
            photo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1vwrzOVj0MUvhnX34_8aUtKSHOP81XlRNRA&usqp=CAU'
        };
        setStudents((prevStudents) => [...prevStudents, newStudent]);
    };

    const handleDeleteSelected = () => {
        const updatedStudents = students.filter((student) => !student.selected);
        setStudents(updatedStudents);
    };

    const handleToggleSelect = (studentId) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === studentId ? { ...student, selected: !student.selected } : student
            )
        );
    };

    const handleEditName = (studentId, newName) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === studentId ? { ...student, name: newName } : student
            )
        );
    };

    const sortedStudents = [...students].sort((a, b) => a.name.localeCompare(b.name));

    const [selectedDiscipline, setSelectedDiscipline] = useState('Веб-разработка');

    const [SelectedCourse, setSelectedCourse] = useState('5');

    const handleDisciplineChange = (e) => {
        setSelectedDiscipline(e.target.value);
    };

    const handleCourseChange = (e) => {
        setSelectedCourse(e.target.value);
    };

    const [dates, setDates] = useState(['2023-03-12', '2023-03-19', '2023-03-26']);

    const [selectedDate, setSelectedDate] = useState('');

    const handleDateChange = (e) => {
        setSelectedDate(e.target.value);
    };

    const handleAddDate = () => {
        if (selectedDate && !dates.includes(selectedDate)) {
            setDates([...dates, selectedDate].sort());
        }
    };

    return (
        <div className="container mt-4" style={{paddingBottom: '100px'}}>
            <div style={{display: 'flex', flexDirection: 'row'}} className="box mr-2">
                <Link to="/" className="btn btn-dark mb-3" style={{ marginRight: '20px' }}>
                    <i className="fas fa-home"></i>
                </Link>
                <h2 style={{ marginRight: '20px' }}>Группа {groupId},</h2>
                <h2 className="mr-3">
                    Семестр:
                    <select value={SelectedCourse} onChange={handleCourseChange}
                            className="form-control d-inline-block ml-2 text-center"
                            style={{
                                width: '40px',
                                marginRight: '10px',
                                padding: '0.15rem',
                                appearance: 'none'
                            }}>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                    </select>
                </h2>
            </div>
            <div className={'form-inline'} style={{marginBottom: '10px'}}>
                <label className="mr-3 form-inline">
                    Дисциплина:
                    <select value={selectedDiscipline} onChange={handleDisciplineChange}
                            className="form-control d-inline-block ml-2 text-center"
                            style={{appearance: 'none'}}>
                        <option value="Веб-разработка">Веб-разработка</option>
                        <option value="NLP">NLP</option>
                        <option value="Глубокое обучение">Глубокое обучение</option>
                        <option value="Философия">Философия</option>
                    </select>
                </label>
                <label className="mr-3 form-inline">
                    Дата:
                    <input type="date" value={selectedDate} onChange={handleDateChange}
                           className="form-control d-inline-block ml-2 text-center"/>
                </label>
                <button onClick={handleAddDate} className="btn btn-dark ml-2">Добавить дату</button>
            </div>
            <table className="table text-center">
                <thead>
                <tr>
                    <th>Фото</th>
                    <th style={{width: '230px'}}>Имя студента</th>
                    {dates.map((date, index) => (
                        <th key={date} style={{whiteSpace: "nowrap"}} >
                            <span style={{display: 'inline-block'}}> {date}</span>
                            <button style={{display: 'inline-block', width: '1.2rem', height:'1.2rem', padding: '2px', fontSize: '10px'}}
                                onClick={() => {
                                handleRemoveDate(date)
                            }} className="btn btn-danger ml-2">
                                <i className="fas fa-trash-alt"></i>
                            </button>
                        </th>
                    ))}
                    <th>Сумма баллов</th>
                    <th>Выбор</th>
                </tr>
                </thead>
                <tbody>
                {sortedStudents
                    .filter((student) => student.group === groupId)
                    .map((student) => (
                        <tr key={student.id}>
                            <td>
                                <div className="student-photo text-center">
                                    <img style={{aspectRatio: 1}} src={student.photo} className="img-thumbnail" alt={"Фото"}/>
                                </div>
                            </td>
                            <td>
                                <input
                                    type="text"
                                    value={student.name}
                                    onChange={(e) => handleEditName(student.id, e.target.value)}
                                    className="form-control text-center"
                                />
                            </td>
                            {dates.map((date) => (
                                <td key={date}>
                                    <div className="d-flex flex-row justify-content-center"> {/* измененный контейнер */}
                                        <div style={{display: 'flex', flexDirection: 'row'}}>
                                                <select
                                                    value={student.attendance[date] || '+'}
                                                    onChange={(e) => handleToggleAttendance(student.id, date, e.target.value)}
                                                    className="form-control text-center"
                                                    style={{
                                                        width: '40px',
                                                        marginRight: '10px',
                                                        padding: '0.15rem',
                                                        appearance: 'none',
                                                        marginBottom: '0 !important'
                                                    }}
                                                >
                                                    {attendanceOptions.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>
                                                <input
                                                    type="text"
                                                    value={student.grades[date] || ''}
                                                    onChange={(e) => handleSetGrade(student.id, date, e.target.value)}
                                                    placeholder="Балл"
                                                    className="form-control text-center"
                                                    style={{width: '60px', padding: '0.15rem'}}
                                                />
                                        </div>
                                    </div>
                                </td>
                            ))}


                            <td>{Object.values(student.grades).reduce((acc, curr) => acc + (curr ? parseInt(curr) : 0), 0)}</td>
                            <td>
                                <input
                                    type="checkbox"
                                    checked={student.selected || false}
                                    onChange={() => handleToggleSelect(student.id)}
                                />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button onClick={handleAddStudent} className="btn btn-dark mr-2">Добавить студента</button>
            <button onClick={handleDeleteSelected} className="btn btn-danger"><i className="fas fa-trash-alt"></i>
            </button>
        </div>
    );
}


export default GroupPage;
