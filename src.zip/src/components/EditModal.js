import React, { useState, useEffect } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function EditModal({ show, handleClose, onEdit, studentToEdit }) {
    const [editedStudent, setEditedStudent] = useState({ ...studentToEdit });

    useEffect(() => {
        setEditedStudent({ ...studentToEdit });
    }, [studentToEdit]);

    const handleEditClick = () => {
        onEdit(editedStudent);
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Редактировать студента</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group>
                        <Form.Label>Фамилия</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите фамилию"
                            value={editedStudent.surname}
                            onChange={(e) => setEditedStudent({ ...editedStudent, surname: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Имя</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите имя"
                            value={editedStudent.name}
                            onChange={(e) => setEditedStudent({ ...editedStudent, name: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Возраст</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите возраст"
                            value={editedStudent.age}
                            onChange={(e) => setEditedStudent({ ...editedStudent, age: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Средний балл</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите средний балл"
                            value={editedStudent.avg_points}
                            onChange={(e) => setEditedStudent({ ...editedStudent, avg_points: e.target.value })}
                        />
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button className="btn btn-danger" onClick={handleClose}>
                    Закрыть
                </Button>
                <Button className="btn btn-success" onClick={handleEditClick}>
                    Редактировать
                </Button>
            </Modal.Footer>
        </Modal>
    );
}

export default EditModal;
