import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function AppendModal({ show, handleClose, onAdd })  {
    const [newStudent, setNewStudent] = useState({surname:'', name: '', age: '' , avg_points: ''});

    const handleAddClick = () => {
        onAdd(newStudent);
        setNewStudent({surname:'', name: '', age: '' , avg_points: ''});
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Добавить студента</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group>
                        <Form.Label>Фамилия</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите фамилию"
                            value={newStudent.surname}
                            onChange={(e) => setNewStudent({ ...newStudent, surname: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Имя</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите имя"
                            value={newStudent.name}
                            onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group >
                        <Form.Label>Возраст</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите возраст"
                            value={newStudent.age}
                            onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Средний балл</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите средний балл"
                            value={newStudent.avg_points}
                            onChange={(e) => setNewStudent({ ...newStudent, avg_points: e.target.value })}
                        />
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button className="btn btn-danger" onClick={handleClose}>
                    Закрыть
                </Button>
                <Button className="btn btn-success" onClick={handleAddClick}>
                    Добавить
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default AppendModal;
