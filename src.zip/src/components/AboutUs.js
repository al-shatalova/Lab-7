import React from 'react';

function AboutUs() {
    return (
        <div>
            <div className="text-center">
                <h2 className="mt-4 ">О нас</h2>
                Финансовый Университет при правительстве РФ - the best of the best!
            </div>

            <div className="text-center mt-4">
                    <h3>Контакты</h3>
                    <p>Почта: ibaslata@icloud.com</p>
                    <p>Телефон: +7 977 364-87-37</p>
                    <p>Адрес: г.Москва, Рязанка</p>
            </div>
        </div>
    );
}

export default AboutUs;
