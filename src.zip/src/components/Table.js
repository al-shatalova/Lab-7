import React, {useState} from 'react';
import Button from "react-bootstrap/Button";
import AppendModal from "./AppendModal";
import EditModal from "./EditModal";

function Table({students, onDelete, onAdd, onEdit}) {

    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [surnameFilter, setSurnameFilter] = useState('');
    const [selectedStudent, setSelectedStudent] = useState(null);



    const handleShowAddModal = () => setShowAddModal(true);
    const handleCloseModal = () => setShowAddModal(false);

    const handleShowEditModal = (student) => {
        setSelectedStudent(student);
        setShowEditModal(true);
    };

    const handleCloseEditModal = () => {
        setSelectedStudent(null);
        setShowEditModal(false);
    };


    const filteredStudents = students.filter((student) =>
        surnameFilter ? student.surname.toLowerCase().includes(surnameFilter.toLowerCase()) : true
    );

    return (
        <div className="p-3">
            <div className="text-center">
                <h2>Журнал ПИ21-5</h2>
            </div>
            <div className="d-flex justify-content-center align-items-center mb-3 m">
                <div className="d-flex flex-column align-items-center">
                    <div className="mr-2 px-4 mb-3">
                        <input
                            type="text"
                            placeholder="Введите фамилию"
                            value={surnameFilter}
                            onChange={(e) => setSurnameFilter(e.target.value)}
                            className="form-control"
                        />
                    </div>
                    <Button className={'btn btn-success'} variant="dark" onClick={handleShowAddModal}>
                        Добавить
                    </Button>
                </div>
            </div>


            <table className="table">
                <thead className="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Фамилия</th>
                    <th>Имя</th>
                    <th>Возраст</th>
                    <th>Средний балл</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                {filteredStudents.map((student) => (
                    <tr key={student.id}>
                        <td>{student.id}</td>
                        <td>{student.surname}</td>
                        <td>{student.name}</td>
                        <td>{student.age}</td>
                        <td>{student.avg_points}</td>
                        <td>
                            <button
                                className="btn btn-danger"
                                onClick={() => onDelete(student.id)}
                            >
                                🗑
                            </button>
                            <button
                                className="btn btn-info"
                                onClick={() => handleShowEditModal(student)}
                            >
                                ✏
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <AppendModal show={showAddModal} handleClose={handleCloseModal} onAdd={onAdd}/>
            <EditModal show={showEditModal} handleClose={handleCloseEditModal} onEdit={onEdit}
                       studentToEdit={selectedStudent}/>
        </div>
    );
}

export default Table;
