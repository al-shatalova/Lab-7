import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
    return (
        <div className="container mt-5">
            <div className="text-center">
                <img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABRFBMVEX///9Ob7bdSkD39/elpaXeSj7iSTvKQTv549z8/PzcSz7//v////r57uVQbrbdSkLk7O3DQUDYTT9McLChoaFIYa/6//+tra3///jKysrQQTXx493u7u7o6OhQbblOb7K4uLjc3NzT09P2287Dw8Pe3t5IYbDLS0S0tLT/9/T/+v/kR0BQbb397u1DY6W6xNNOcazq4OLh09XYxsXNta/DqJ7EhInAc3f38uS+XF60QkC7RT3mx8X+7PXira/BRjnajZTYcnrFUErhs6rRkYjKa2TQinm9V0b31dLs//nUfW/RTDbYfn3bPD7goqDXiIbPZ2F3jKw2W5Gfssjlyr13iLiMm7Veb6eeqMbM1+RJZpZigKxZerBRZqdwiLnQZFivwdLis6PQVFiFlsebq9SLi4vh6/bH199gep3oPDbCkov1zdSJ+HtKAAAKs0lEQVR4nO2d+VfbyhXHR5aXjGeQHWyPxsaWhGKDN4TTNW3T8MryHtlDnAAmkNC+1KTt//9774y8g+k5acDWnPkeiC1rOEef3Dt3GckSQlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWj9aBFFOF30QdyyTqk5YbuBFH8Idq6I84eMttb0Us9+oTkh/qzghor/bYos+hjsV479XnJCgPzwhiz6IOxVGf1SckDT+pDgh2/rzk0Ufw92KPfjL1qKP4W7Fnu78VfF8+Ex1QvqT6oT8bzvNRR/D3Qpvqh5p1lK7ihMellQn3GspTEjEz35md2XRB3JnIogRdLC6qS4hIozxhy2FCWmTPH+Qau2oTNjke6nkzoqy3RPDDO0nEgp7KcIMH6hNSNnWruKE9LCkNCFrsr1WTG1C9LPahBQ1fokJQmWzBXp+uJNQmhA/f1ZKxNIpdb20yV+8TKZXH6pLyFY2k2m1CZ+WkjGlCfmrdDKjNOHKw3SipTThWirZUpvwMJXMJJQmfPo6oTxhWmVCQtBeLJHOpNOKEgIgehZLrCpMyBB5ozph86eMyoSIYvQ2FkurW7Uxjtkr4JOVt5L9IeOEH8RUJsQU83erKhOWKeNfVCWkiHJzGzr8zURM+Kl6kQYIae8KNZ+k1CVE7KhGyYrKhP33WY5XXqtKyCjqBozSR+oScvMsgLn4qBRTlJDzy8AFwg+vVSWk7MT5CLNxT1lCtF1oHytLCNUof35ykTsFS74J56FiNY0g3C5YVlcQJlQkZAQCadva2AYv3U8OCRd9VD9UBHWtdmejB4RvlSTEPNsxrFyhD3n/VUtNwq7luk6QBcIDJech7p8ZhuF0TEHYUpGQ/eoajmWdM8oa75QkvCpYOSD8BMmisasaIeXEZOc517Is4whsuLW5qhghoZx1g5wBgMYxEK6lFCTsXxgACIhdKgjTihFCjj9yJJ8VXHLOHqRUyhYUEUJRL2hLQLewzSl7lEkolvGpeWI5hsyGGz2K0YeSUoSUc9QttDshYSHLgVACqkIIPRPrnbXbuZAwyFJG9lpKEVLGPolqRhC2OwEThErZkBJ0WjAGylkdxBHbL0kjriaUuDaR8F6QGxE6nxHMw7chYVoNwubzk/aI0HWO5BngdEiYTK0t+vB+gNhXw3GGhIZzSsFNX70cEj5Y9OH9nyKQ768Cx2mPbLgh1qHoQWjDROQJxdlCdO62xybMiXUo1vgiy1IVCCHZ9wPLcd0xYU+2h8oQIs4uC45lTdiwTzFrbKpCyAhmR1Buj93U3YCijTVSqhBSTLMXYwOKmuaEiRt+lNIZNQiB5iowpgjP1SKEvvB4CtBwPkG3qBIhZxfONOGRIHzaSihD2CtM29A4Fd8effpalUiD0WnbnQJ0oaShbO/1akINQsQ+zZgw2BaFd/QJsfwBQd9kTRP2KBC+iTwhqtimfD01OjOEfU4JjTghxqgStzEnMOG+uRM2FOulQRZzTF+stlYjTIhQOR73CSWc9y6cnDFN+DzyhFgAFuNlDITs1GmP2wpJ2OFNTtGLTKQJy3F/vY6AELMzd8aGzmcKhORdlAmFBZG9Lm9e0gtcYyodWs4RbUIw/ZLOpCNKiCVgJS5yRRMdT1dsOSA8FW7c+CUZ3VgqAJEHvwgT82w62+cg0FwKwq3dqBKKNAFwlbhIhphuBzOEjgMlDQHCneRqROvSSt4HzGpVFjX0o3ON8H1PDHscTUKAWs+vi5mYl/UM7wczhE47F2TFrsepRDRjqZ+viIIGTChEuzMlqSB0JfxhFAnBgpDmxZuyfIG24sR1ZxDbbkfuOiylI0iIPSi2RZLwqkiemr/aMDrOLOG5HPwUCCOXD8u2h4WLQrAxEYUwg47aljtN6LaNIzl4Lxm9jF+Jy/gJv3VIF5xiiDPuxDJpSGgYXTn678lM1GKpL4Ko7HlropwBG7JuAFWoNUPoXsrhb4AwQhkfnLM6CC6wYftILHVT1pFXz8wQBtvynrr7yViUCGEK1s3hYzh8G4MtGUE96zqhYQU9Lkbtt1YzUSGUab443MAmZERQs4FmV6BkTRMmfIJ+TiVjkVkvNavxCho9SKXqyRcRZ2btJ7w0d8HkbUsPMsnIrHlXbM+c2BrMR8qOr3mocNLOeUj4TnxTPRKEuJj3J7ft4Vb2LLwCaibhdz5TSfiPTDoKhFBi27Y5ue3bcPRcFDTdwLmB0DK+coYIJptRIMTSgFNPMgrDDCecsrPJBajxPGxfUkYIa6Zi6czSE8IMrJfRFKEnewqxxHbp3EhoONucEUy3okAIIdSfeRTVuuzswQk5O4M+6aZIE/Q5IZQ/iAChH/fMaQMiM14L31DxHcprbYU0YZCVhIdLTohRpW7Xrn0a+qg4ZYjPb7Cf1AVDnDXZh1IskVji3sKs5osYzT4tbeCjourenl29GHnpCVp6QiDz85M5figzP7QqZZ+s9hzCX2GWijuzLjPhul2voGsGHMZRIXIZ3FTPSMKvnDQZWWbCdTucgDOEkOvjWLaFhBLz3DXmEELvBNlQEorb7wjCRGmZCGu2OB1xk8phS8EhzKDLAILmHMKeKNkItPixgRKZ0qP7RLhVYL/1OQ9jxIN6lDIKudBw3XmEfSomIt1PLBuhiC/xefYTa9xe6LeMcXZqOLncHMJOU5Q0DL1dOkKzGLdr+KYAI+UPEwVMQ3GpZWce4WcSEr5aHkK5uFSu5r3KLYMq+eHeJr92qmIcRx0rdyyzIRl8Q3YpCIGxVs9Xy4N1tBtlxv2hcfnkRfnXCYNLmKmC8N1yEErzFeNx35zrnlKeN3rL2Yl1G2EPM8gVuPFlOQghu3vgnvOnXzioaE/sPi3MA5SE2QZjmJPG7qIJpUtWqnnbF/0DNjFBZVGImhhUniYeRRlMxBXdxrwgIxr8AEGUIZStbMYWbkPhndUwflTyHhSdVSg7/X/WYKuaN8eEuDaKMkDIPrtzyxnDtYxPYhwUNSsvF2bD8NArRRvwcGhL7K17yK8CZLnorSO7LDZGqozqbcQ46kJbOJfQsNzTAeFaaTE2lA2RWasO8MYUngAp5iGm1FCxXhvV2PLCmdEwRiGO3kZo5LYHIx+UFmXDsu/F7eLQekMBIan4tbgkRLX16nCFG/JEcTyMsHOjc6sN3/cHAw/vl1BEDySNF497fvnabrNWhwgjlihMzzdHJ+lF4BmcUBNilB471k2LTwM5rnsxfPDvh3v3UumaYDwT3ZDZi3VIeF69hrHnecWy7Q0X2Ey7OhlWL8+c+Q4qTOt+lIQUob37IMSDZQizAp6Zrxdrtz7C/fpOHAKGgo4C9wLXmdf4DozYlee+74tQuF/FF6ar+pVb6eaobI9dFFHe7xi3BRmxGBxcjQhbd0yIyxW/6AGc59fKMMW+Q1hc+oTH5Sj7Bgyg3KTc4Sfi1WgHLFxORejNv5JjlR79+Odyl/NxkC0U/275E65L+h8LGwUh8e/GxuDN6BOhIPjG5F8Qgv6dGuv1w//8+HsqfJfVrllxwrVpuZL9n+pnafgnhGytTcqMwrPVMaXy5DWd0ugT8YbT8KSUKO/QmIkQ0ozAfTGIuMW6QMFTGn0i3gAeDwfDJhn9LzDc/J44p6WlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWldY/6L0ZgOW5gECG/AAAAAElFTkSuQmCC"
                    alt="Логотип вуза" className="img-fluid mb-4"/>
                <h1 className="display-4">Финансовый университет при Правительстве РФ</h1>
                <p className="lead">Расписание:</p>
            </div>
            <div className="container mt-5 d-flex justify-content-center align-items-center">
            <ul className="list-group" style={{width: '350px'}}>
                <li className="list-group-item text-center">Список групп:</li>
                <li className="list-group-item text-center">
                    <Link to="/group/ПИ21-1">Группа ПИ21-1</Link>
                </li>
                <li className="list-group-item text-center">
                    <Link to="/group/ПИ21-2">Группа ПИ21-2</Link>
                </li>
                {/* Добавьте ссылки для других групп, если необходимо */}
            </ul>
            </div>
        </div>
    );
}

export default HomePage;
