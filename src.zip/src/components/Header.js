import React from 'react';
import {Link} from 'react-router-dom';

function Header() {
    return (
        <nav className="navbar navbar-dark bg-secondary navbar-expand-lg px-4 ">

            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                    aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div className="navbar-nav">
                    <Link className="nav-item nav-link" to="/">Главная</Link>
                    <Link className="nav-item nav-link" to="/about-us">О нас</Link>
                    <Link className="nav-item nav-link">Стажировки</Link>
                    <Link className="nav-item nav-link">Спорт</Link>
                    <Link className="nav-item nav-link">Студентам</Link>
                    <Link className="nav-item nav-link">Преподавателям</Link>
                </div>
            </div>
        </nav>
    );
};

export default Header;
