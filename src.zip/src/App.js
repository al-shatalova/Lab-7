import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Table from './components/Table';
import AboutUs from './components/AboutUs';

const App = () => {
    const [students, setStudents] = useState([
        {id: 1, surname:'Басалаев', name: 'Иван', age: 19, avg_points: 85},
        {id: 2, surname:'Ветютнев', name: 'Сергей', age: 20, avg_points: 90},
        {id: 3, surname:'Зарубин', name: 'Роман', age: 21, avg_points: 83},
        {id: 4, surname:'Тарасов', name: 'Иван', age: 22, avg_points: 78},
        {id: 5, surname:'Катков', name: 'Иван', age: 21, avg_points: 52},
        {id: 6, surname:'Урусов', name: 'Глеб', age: 20, avg_points: 53},
        {id: 7, surname:'Орлов', name: 'Дмитрий', age: 19, avg_points: 67},
        {id: 8, surname:'Шпанский', name: 'Егор', age: 18, avg_points: 99},
        {id: 9, surname:'Дранникова', name: 'Елена', age: 17, avg_points: 100},
        {id: 10, surname:'Иванов', name: 'Дмитрий', age: 18, avg_points: 98},
    ]);

    const handleDelete = (studentId) => {
        setStudents(students.filter((student) => student.id !== studentId));
    };

    const handleAdd = (newStudent) => {
        const maxID = Math.max(0, ...students.map(student => student.id));
        setStudents([...students, { id: maxID + 1, ...newStudent }]);
    };

    const handleEdit = (editedStudent) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === editedStudent.id ? editedStudent : student
            )
        );
    };

    return (
        <Router>
            <div>
                <Header />
                <Routes>
                    <Route
                        path="/"
                        element={<Table students={students} onDelete={handleDelete} onAdd={handleAdd} onEdit={handleEdit} />}
                    />
                    <Route path="/about-us" element={<AboutUs />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
