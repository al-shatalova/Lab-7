import React, {useState} from 'react';

import AddStudentModal from "./AddStudentModal";
import { Table, TableBody, TableCell, TableHead, TableRow,Button, TextField, Box, Typography } from '@mui/material';

const MainTable = ({ students, onDelete, onAdd }) => {
    const [showModal, setShowModal] = useState(false);
    const [ageFilter, setAgeFilter] = useState('');

    const handleShowModal = () => setShowModal(true);
    const handleCloseModal = () => setShowModal(false);

    const filteredStudents = students.filter((student) =>
        ageFilter ? student.age === parseInt(ageFilter, 10) : true
    );

    return (
        <Box p={3}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                <Typography variant="h5">Таблица студентов</Typography>
                <Box display="flex">
                    <TextField
                        label="Фильтр по возрасту"
                        value={ageFilter}
                        onChange={(e) => setAgeFilter(e.target.value)}
                        margin="normal"
                        variant="outlined"
                    />
                    <Button color="primary" variant="contained" onClick={handleShowModal} style={{ marginLeft: 16 }}>
                        Добавить
                    </Button>
                </Box>
            </Box>

            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>ID</TableCell>
                        <TableCell>Фамилия</TableCell>
                        <TableCell>Имя</TableCell>
                        <TableCell>Возраст</TableCell>
                        <TableCell>Средний балл</TableCell>
                        <TableCell>Действие</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {filteredStudents.map((student) => (
                        <TableRow key={student.id}>
                            <TableCell>{student.id}</TableCell>
                            <TableCell>{student.second_name}</TableCell>
                            <TableCell>{student.name}</TableCell>
                            <TableCell>{student.age}</TableCell>
                            <TableCell>{student.aver_mark}</TableCell>
                            <TableCell>
                                <Button
                                    color="secondary"
                                    variant="contained"
                                    onClick={() => onDelete(student.id)}
                                >
                                    Удалить
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            <AddStudentModal show={showModal} handleClose={handleCloseModal} onAdd={onAdd} />
        </Box>
    );
};

export default MainTable;
