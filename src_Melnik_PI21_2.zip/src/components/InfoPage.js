import React from 'react';
import { Container, Grid, Typography, Avatar, Box } from '@mui/material';

const InfoPage = () => {
    return (
        <Container>
            <Typography variant="h4" className="mt-4">Немного о нас</Typography>

            <Grid container spacing={3} className="mt-4">
                <Grid item md={6}>
                    <Typography variant="h5">Гуд морнинг чилдрен</Typography>
                    <Typography>
                        Тут типо должен быть текст, как у всех, но у меня нет фантазии, а чатгпт не работает, впн сломался
                    </Typography>
                </Grid>

                <Grid item md={6}>
                    <Typography variant="h5">Контакты</Typography>
                    <Typography>Email: Genudza@yandex.ru</Typography>
                    <Typography>Телефон: +7 930 011 81 56</Typography>
                    <Typography>Адрес: г. Лобня, ул.Пушкина , д.4, к.1</Typography>
                </Grid>
            </Grid>

            <Typography variant="h4" className="mt-4">Команда</Typography>

            <Grid container spacing={3} className="mt-4">
                <Grid item md={4}>
                    <Box display="flex" flexDirection="column" alignItems="center" mb={4}>
                        <Avatar
                            src="https://sun9-44.userapi.com/impg/J0KExFD_E1RMGG8P84aPwslyKsf7GUhhU-ymbA/TybzxOWcaoU.jpg?size=1620x2160&quality=95&sign=3b7478d3585b3dc280df28181f958d50&type=album"
                            alt="Я"
                            sx={{ width: 384, height: 394, mb: 2 }}
                        />
                        <Typography variant="h6">Мельник Геннадий</Typography>
                        <Typography>Позиция: Недокодер</Typography>
                        <Typography>Обожаю кофе и высоких девушек.</Typography>
                    </Box>
                </Grid>
            </Grid>
        </Container>
    );
};

export default InfoPage;
