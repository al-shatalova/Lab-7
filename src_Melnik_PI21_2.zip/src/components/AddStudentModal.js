import React, { useState } from 'react';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
};

const AddStudentModal = ({ show, handleClose, onAdd }) => {
    const [newStudent, setNewStudent] = useState({ second_name:'', name: '', age: '' , aver_mark: '' });

    const handleAddClick = () => {
        onAdd(newStudent);
        setNewStudent({ second_name:'', name: '', age: '' , aver_mark: '' });
        handleClose();
    };

    return (
        <Modal open={show} onClose={handleClose}>
            <Box sx={style}>
                <Typography id="modal-modal-title" variant="h6" component="h2">
                    Добавить студента
                </Typography>
                <Box component="form" noValidate sx={{ mt: 2 }}>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Фамилия"
                        value={newStudent.second_name}
                        onChange={(e) => setNewStudent({ ...newStudent, second_name: e.target.value })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Имя"
                        value={newStudent.name}
                        onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Возраст"
                        value={newStudent.age}
                        onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Средний балл"
                        value={newStudent.aver_mark}
                        onChange={(e) => setNewStudent({ ...newStudent, aver_mark: e.target.value })}
                    />
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
                        <Button onClick={handleClose} sx={{ mr: 2 }}>
                            Закрыть
                        </Button>
                        <Button variant="contained" color="primary" onClick={handleAddClick}>
                            Добавить
                        </Button>
                    </Box>
                </Box>
            </Box>
        </Modal>
    );
};

export default AddStudentModal;
