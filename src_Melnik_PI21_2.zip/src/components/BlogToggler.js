import React, { useRef, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Image } from "react-bootstrap";
import { Grid, Button } from '@mui/material';
const trendData = {
    IT: [
        { id: 1, title: 'Искусство взлома', content: 'школа Dark Side открывает набор талантливых ребят для взлома вражеских гос.сайтов.', img: "https://avatars.yandex.net/get-music-content/4399644/de2006e9.a.14385165-1/m1000x1000?webp=false" },
        { id: 2, title: 'Будущее технологий вр', content: 'Спрогнозируем развитие вр и других костылей для погружения.', img: "https://u.9111s.ru/uploads/202302/13/2e7e730e7dbd43dbe6b1efb3f11a18f9.jpg"},
        { id: 3, title: 'Этические вопросы ИИ', content: 'На нашей открытой лекции , мы обсудим проблему этики в ии', img:"https://static.tildacdn.com/tild6638-3130-4261-a437-623030343937/Volume1_infogr-05.jpg" },
    ],
    Sport: [
        { id: 1, title: 'Спорт: Травма Насилие Сломанное Детство', content: 'Обсудим, как из-за хотелок родителей дети вырастают закомплексованными спортсменами', img: "https://www.thesun.co.uk/wp-content/uploads/2023/03/enrique-llopis-spain-receives-treatment-800687851-1.jpg" },
        { id: 2, title: 'Экстремальные виды спорта', content: 'Займёмся скалолазанием без страховки', img: "https://w.forfun.com/fetch/cc/cc2c9530bd748a6fdf44cc9865933c15.jpeg"},
    ],
    Politics: [
        { id: 1, title: 'Глобальная политика: Конец Сво', content: 'Дадим прогнозы, когда Россия победит', img:"https://ptoday.ru/wp-content/uploads/2023/10/87k6vych.jpg" },
        { id: 2, title: 'Израиль и Палестина', content: 'Обсудим мирные варианты решения конфликта с сохранением Иерусалима за Израилем', img:"https://vsegda-pomnim.com/uploads/posts/2022-01/1642862134_30-vsegda-pomnim-com-p-ierusalimskii-khram-foto-33.jpg" },
    ],
    Music: [
        { id: 1, title: 'Музыкальные новинки: Открой для себя лучших нефоров России', content: 'Представляем самые свежие музыкальные треки от дуэта Viperr в предверии PropagandaTour.', img:"https://i.ytimg.com/vi/R-3SH3paAB8/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYACzgWKAgwIABABGGUgXyhSMA8=&rs=AOn4CLAsENp1mvTwN84Gb3AG_6eXB2ZMxQ" },
        { id: 2, title: 'Творческий процесс "артистов"', content: 'Сталкиваем артистов старого и нового поколения', img:"https://100biografiy.ru/wp-content/uploads/2023/10/maxresdefault-25.jpg" },
    ],
    Other: [
        { id: 1, title: 'Путешествия и приключения', content: 'Показываем передачу об экстремальных странах(Сомали)', img:"https://kadet39.ru/wp-content/uploads/1/b/7/1b7d9137b51e90526967e19d46cc5beb.jpeg" },
        { id: 2, title: 'Наука и открытия', content: 'Рассказываем о новых русских разработках', img:"https://pervoe.online/upload/iblock/3d7/x1lrn4uuopw1otunyvcuigmfqt7zhnkj.jpg" },
    ]
};

export default function BlogToggler() {
    const [activeTrend, setActiveTrend] = useState(null);
    const trendRefs = useRef(
        Object.keys(trendData).reduce((acc, trend) => {
            acc[trend] = Array(trendData[trend].length)
                .fill(0)
                .map(() => React.createRef());
            return acc;
        }, {})
    );

    function handleScrollToPost(trend, index) {
        trendRefs.current[trend][index].current.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
        });
    }

    function handleTrendClick(trend) {
        setActiveTrend(trend);
    }

    return (
        <Grid container spacing={3}>
            {Object.keys(trendData).map((trend) => (
                <Grid item key={trend}>
                    <Button
                        variant={activeTrend === trend ? 'contained' : 'outlined'}
                        color="primary"
                        onClick={() => {
                            handleScrollToPost(trend, 0);
                            setActiveTrend(trend);
                        }}
                    >
                        {trend}
                    </Button>
                </Grid>
            ))}
        </Grid>
    );
}
