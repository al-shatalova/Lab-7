import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import MainTable from './components/MainTable';
import InfoPage from './components/InfoPage';
import Blog from "./components/Blog";

const App = () => {
    const [students, setStudents] = useState([
        { id: 213832, second_name:'Мельник', name: 'Геннадий', age: 20, aver_mark: 98},
        { id: 213833, second_name:'Парменова', name: 'Дарья', age: 21, aver_mark: 96 },
        { id: 198345, second_name:'Чеплакова', name: 'Анна', age: 22, aver_mark: 94 },
        { id: 204647, second_name:'Казиева', name: 'Карина', age: 23, aver_mark: 92 },
    ]);

    const handleDelete = (studentId) => {
        setStudents(students.filter((student) => student.id !== studentId));
    };

    const handleAdd = (newStudent) => {
        setStudents([...students, { id: students.length + 1, ...newStudent }]);
    };

    return (
        <Router>
            <div>
                <Header />

                <Routes>
                    <Route
                        path="/"
                        element={<MainTable students={students} onDelete={handleDelete} onAdd={handleAdd} />}
                    />
                    <Route path="/info" element={<InfoPage />} />
                    <Route path="/blog" element={<Blog />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
