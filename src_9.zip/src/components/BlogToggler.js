import React, { useRef, useState } from 'react';
import { Image } from "react-bootstrap";

const trendData = {
    IT: [
        {
            id: 1,
            title: 'The Art of Coding',
            content: 'Explore the refined art of coding in our latest material, highlighting the nuances and challenges in crafting efficient code.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/640xH/media/img/5/09/347024542850095.webp'
        },
        {
            id: 2,
            title: 'Future Technologies',
            content: 'Forecast the technological future; discuss key trends and innovations that will reshape our world.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/640xH/media/img/1/54/347019455135541.webp'
        },
        {
            id: 3,
            title: 'Ethical Issues in IT',
            content: 'Delve into the ethical aspects of using information technologies, confronting modern developers and engineers.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/640xH/media/img/8/21/347018623347218.webp'
        },
    ],
    Economics: [
        {
            id: 1,
            title: 'Economic Championships: Beyond the Numbers',
            content: 'Explore the economic world as we unveil insights into unusual financial strategies, economic trends, and personal success stories.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/900xH/media/img/9/68/347029728050689.webp'
        },
        {
            id: 2,
            title: 'Navigating Economic Extremes',
            content: 'Embark on a journey into the economic extremes, revealing daring financial maneuvers, adventures, and the passions of those who thrive in the world of finance.',
            img: 'https://prometheus.ru/wp-content/uploads/2021/12/scale_1200.jpg'
        },
    ],
    Science: [
        {
            id: 1,
            title: 'Cutting-Edge Discoveries: Unveiling the Latest Trends in Scientific Research',
            content: 'Explore recent breakthroughs and trends in various scientific fields, shedding light on the impact of these discoveries on our understanding of the world.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/640xH/media/img/2/24/347014380529242.webp'
        },
        {
            id: 2,
            title: 'In-depth Interviews with Leading Scientists: Exploring Strategies for Future Discoveries',
            content: 'Delve into conversations with influential figures in the scientific community, discussing strategies, priorities, and the challenges faced by modern scientists in their pursuit of knowledge.',
            img: 'https://s0.rbk.ru/v6_top_pics/resized/640xH/media/img/5/75/346819691689755.webp'
        },
    ]
};

export default function BlogToggler() {
    const [activeTrend, setActiveTrend] = useState(null);
    const trendRefs = useRef(
        Object.keys(trendData).reduce((acc, trend) => {
            acc[trend] = Array(trendData[trend].length)
                .fill(0)
                .map(() => React.createRef());
            return acc;
        }, {})
    );

    function handleScrollToPost(trend, index) {
        trendRefs.current[trend][index].current.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
        });
    }

    function handleTrendClick(trend) {
        setActiveTrend(trend);
    }

    return (
        <div className="container mt-4">
            <div className="row justify-content-center">
                <div className="col-md-12 text-center">
                    {Object.keys(trendData).map((trend) => (
                        <button
                            key={trend}
                            className={`btn btn-primary mr-2 mb-2 mx-2 ${activeTrend === trend ? 'active' : ''}`}
                            onClick={() => {
                                handleScrollToPost(trend, 0);
                                handleTrendClick(trend);
                            }}
                        >
                            {trend}
                        </button>
                    ))}
                </div>
            </div>
            <div className="row justify-content-center">
                {Object.keys(trendData).map((trend) => (
                    <div key={trend} className={`col-md-4 ${activeTrend !== trend ? 'd-none' : ''}`}>
                        <div className="mb-3 d-flex align-items-center">
                            <div className="card-body text-center">
                                <center><h1>{trend}</h1></center>

                                <ul className="list-unstyled">
                                    {trendData[trend].map((post, index) => (
                                        <li key={post.id} ref={trendRefs.current[trend][index]} className="mb-3 card p-3">
                                            <center><h2 className="h4">{post.title}</h2></center>
                                            <center>
                                                <Image
                                                    src={post.img}
                                                    alt={post.id}
                                                    className="mb-3"
                                                    width={320}
                                                    height={200}
                                                />
                                            </center>
                                            <center><p>{post.content}</p></center>
                                        </li>
                                    ))}

                                </ul>
                            </div>
                        </div>
                    </div>
                ))}

            </div>
        </div>
    );
}
