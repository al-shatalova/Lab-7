import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import AddPage from './components/AddPage';
import News from "./components/News";
import Quiz from "./components/Quiz"
const App = () => {
    return (
        <Router>
            <div>
                <Header />
                <Routes>
                    <Route path="/info" element={<AddPage />} />
                    <Route path="/blog" element={<News />} />
                    <Route path="/quiz" element={<Quiz />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
