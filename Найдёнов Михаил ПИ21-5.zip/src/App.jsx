import { useState } from 'react'
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainPage from './pages/MainPage';
import StudentPage from './pages/StudentPage';
import { useParams, Link } from 'react-router-dom';


function App() {
  const [count, setCount] = useState(0)

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="student/:id" element={<StudentPage/>} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
