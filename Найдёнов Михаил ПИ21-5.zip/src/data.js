
const DataMain = () => {
    return [
        {id: 1, name: "Басалаев Иван Александрович",img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67034/ctn-25001.281474976810789_optimized.jpg", score: 0,blanks: 7, attendance: ['н','н','п','н','н','н',],},
        {id: 2, name: "Ветютнев Сергей Дмитриевич",img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/69030/ctn-25001.281474976806648_optimized.jpg" ,score: 0,blanks: 5, attendance: ['н','оп','п','н','н','п',],},
        {id: 3, name: "Дранникова Елена Михайловна", img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67925/ctn-25001.281474976809662_optimized.jpg", score: 0,blanks: 5, attendance: ['н','п','н','н','н','н',],},
        {id: 4, name: "Ерофеев Кирилл Александрович", img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67220/ctn-25001.281474976805717_optimized.jpg", score: 0,blanks: 5, attendance: ['н','оп','п','п','н','н',],},
        {id: 5, name: "Басалаев Иван Александрович",img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67034/ctn-25001.281474976810789_optimized.jpg", score: 0,blanks: 7, attendance: ['н','н','п','н','н','н',],},
        {id: 6, name: "Ветютнев Сергей Дмитриевич",img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/69030/ctn-25001.281474976806648_optimized.jpg" ,score: 0,blanks: 5, attendance: ['н','оп','п','н','н','п',],},
        {id: 7, name: "Дранникова Елена Михайловна", img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67925/ctn-25001.281474976809662_optimized.jpg", score: 0,blanks: 5, attendance: ['н','п','н','н','н','н',],},
        {id: 8, name: "Ерофеев Кирилл Александрович", img: "https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67220/ctn-25001.281474976805717_optimized.jpg", score: 0,blanks: 5, attendance: ['н','оп','п','п','н','н',],},
    ]
}
export default DataMain