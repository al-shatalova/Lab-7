import React from "react"
import Header from "../components/Header"
import DataMain from "../data"
import { useParams } from "react-router-dom"

const StudentPage = () => {
    let mainData = DataMain()
    const { id } = useParams()
    const student = mainData.find((item) => item.id.toString() === id);
  
    if (!student) {
      return <div>Student not found</div>;
    }
  
    return (
        <>
            <Header/>
            <div className="student-page">
                <div><img className="student-page-img" src={student.img} alt="" /></div>
                <div>{student.name}</div>
            </div>
        </>

        
    )
}

export default StudentPage