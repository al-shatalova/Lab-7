import React, { useState } from "react"
import DataMain from "../data"
import { Link } from "react-router-dom"

const Table = () => {
    function getArr() {
        let inputAll = Array.from(document.querySelectorAll('#forms input'));
        let obj = {};
      
        let checkFieldsLength = inputAll.every((el) => el.value.length);
    
        if (checkFieldsLength) {
          for (const input of inputAll) {
            obj[input.id] = input.value;
          }
        // data.push(obj);
        return console.log(obj);
        }
        return alert('Не все поля заполнены');
      }
    const [data, setData] = useState(DataMain())
    return (
        <>
        <table>
            <tr>
                <td rowSpan={4}>№</td>
                <td rowSpan={4}>ФИО</td>
                <td rowSpan={4}>Балл</td>
                <td rowSpan={4}>Пропуски</td>
                <th>Практические (Семинарские занятия)</th>
                <th>Практические (Семинарские занятия)</th>
                <th>Практические (Семинарские занятия)</th>
                <th>Практические (Семинарские занятия)</th>
                <th>Практические (Семинарские занятия)</th>
                <th>Практические (Семинарские занятия)</th>
            </tr>
            <tr className="table-light">
                <th>Шаталова А.Ю</th>
                <th>Шаталова А.Ю</th>
                <th>Шаталова А.Ю</th>
                <th>Шаталова А.Ю</th>
                <th>Шаталова А.Ю</th>
                <th>Шаталова А.Ю</th>
            </tr>
            <tr>
                <th>23.10.2023</th>
                <th>23.10.2023</th>
                <th>06.11.2023</th>
                <th>06.11.2023</th>
                <th>20.11.2023</th>
                <th>20.11.2023</th>
            </tr>
            <tr className="table-light">
                <th>11:50-13:20</th>
                <th>17:20-18:50</th>
                <th>11:50-13:20</th>
                <th>17:20-18:50</th>
                <th>11:50-13:20</th>
                <th>17:20-18:50</th>
            </tr>
            {data.map((rowData) => (
                    <tr>
                        <td>{rowData.id}</td>
                        <Link to={`/student/${rowData.id}`} key={rowData.key}>
                            <td><div className="student-name-img"><img className='student-img' src={rowData.img} alt="" /><div>{rowData.name}</div></div></td>
                        </Link>
                        <td>{rowData.score}</td>
                        <td>{rowData.blanks}</td>
                        {rowData.attendance.map((attendance) => (
                            <td>{attendance}</td>
                        ))}
                        <td><button className="btn btn-danger">УДАЛИТЬ</button></td>
                    </tr>
            ))}
            </table>
                <div className='input-new'>
                <input type="text" id="name" placeholder='Введите Имя' />
                <input type="text" id="score" placeholder='Введите балл' />
                <input type="text" id="blanks" placeholder='Пропуски' />
                <input type="text" name="" id="attendance" placeholder='23.10.2023'/>
                <input type="text" name="" id="" placeholder='23.10.2023'/>
                <input type="text" name="" id="" placeholder='06.11.2023'/>
                <input type="text" name="" id="" placeholder='06.11.2023'/>
                <input type="text" name="" id="" placeholder='20.11.2023'/>
                <input type="text" name="" id="" placeholder='20.11.2023'/>
              </div>
              <button className='btn btn-primary' onClick={getArr()}>ДОБАВИТЬ</button>
        </>
    )
}
export default Table