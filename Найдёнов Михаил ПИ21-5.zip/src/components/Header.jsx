import React from 'react'
import { Link } from 'react-router-dom';



const Header = () => {
  return (
    <header>
      <Link to={`/`}>
      <img  src="https://org.fa.ru/upload/bitrix24/9b9/logo_5ArdErqz.png"></img>
      </Link>
      <div className='header-group'>
        <p>ГРУППА</p>
        <p>ПИ21-5</p>
      </div>
    </header>
    )
}

export default Header;