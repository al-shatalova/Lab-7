import React, { useState } from 'react';
import './App.css';

export default function App() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [fullName, setFullName] = useState('');

  function handleFirstNameChange(e) {
    setFirstName(e.target.value);
    setFullName(e.target.value + ' ' + lastName);
  }

  function handleLastNameChange(e) {
    setLastName(e.target.value);
    setFullName(firstName + ' ' + e.target.value);
  }

  const [answer1, setAnswer1] = useState('');
  const [error1, setError1] = useState(null);
  const [status1, setStatus1] = useState('typing');

  async function handleSubmit1(e) {
    e.preventDefault();
    setStatus1('submitting');
    try {
      await submitForm1(answer1);
      setStatus1('success');
    } catch (err) {
      setStatus1('typing');
      setError1(err);
    }
  }

  function handleTextareaChange1(e) {
    setAnswer1(e.target.value);
  }

  function submitForm1(answer1) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        let shouldError = answer1.toLowerCase() !== 'npm create vite@latest';
        if (shouldError) {
          reject(new Error('Неправильный ответ. Пересдача в начале февраля.'));
        } else {
          resolve();
        }
      }, 500);
    });
  }

  const [answer2, setAnswer2] = useState('');
  const [error2, setError2] = useState(null);
  const [status2, setStatus2] = useState('typing');

  async function handleSubmit2(e) {
    e.preventDefault();
    setStatus2('submitting');
    try {
      await submitForm2(answer2);
      setStatus2('success');
    } catch (err) {
      setStatus2('typing');
      setError2(err);
    }
  }

  function handleTextareaChange2(e) {
    setAnswer2(e.target.value);
  }

  function submitForm2(answer2) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        let shouldError = answer2.toLowerCase() !== 'npm run dev';
        if (shouldError) {
          reject(new Error('Неправильный ответ. Пересдача в начале февраля.'));
        } else {
          resolve();
        }
      }, 500);
    });
  }

  return (
    <>
      <h2>Квиз</h2>
      <label>
        Имя: <input value={firstName} onChange={handleFirstNameChange} />
      </label>
      <label>
        Фамилия: <input value={lastName} onChange={handleLastNameChange} />
      </label>
      <p>
        Ваше имя: <b>{fullName}</b>
      </p>
      <h2>1 вопрос</h2>
      <p>Какой командой создаётся проект в Vite?</p>
      <form onSubmit={handleSubmit1}>
        <textarea
          value={answer1}
          onChange={handleTextareaChange1}
          disabled={status1 === 'submitting'}
        />
        <br />
        <button disabled={answer1.length === 0 || status1 === 'submitting'}>
          Ответить
        </button>
        {error1 !== null && <p className="Error">{error1.message}</p>}
      </form>
      {status1 === 'success' && <h1>Правильно!</h1>}

      <h2>2 вопрос</h2>
      <p>Какой командой запускается проект в Vite?</p>
      <form onSubmit={handleSubmit2}>
        <textarea
          value={answer2}
          onChange={handleTextareaChange2}
          disabled={status2 === 'submitting'}
        />
        <br />
        <button disabled={answer2.length === 0 || status2 === 'submitting'}>
          Ответить
        </button>
        {error2 !== null && <p className="Error">{error2.message}</p>}
      </form>
      {status2 === 'success' && <h1>Правильно!</h1>}
    </>
  );
}
