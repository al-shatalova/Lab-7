import React from 'react';
import { useParams } from 'react-router-dom';
import { studentsData } from './studentsData';

const StudentDetailPage = () => {
    const { id } = useParams();
    const student = studentsData.find((s) => s.id === parseInt(id, 10));

    if (!student) {
        return <div>Студент не найден, либо его данные еще не появились в системе</div>;
    }

    return (
        <div>
            <h1>Страница студента: {student.fullName}</h1>
            {student.photoLink && (
                <img src={student.photoLink} alt={`Фотография студента ${student.fullName}`} style={{ maxWidth: '300px' }} />
            )}
            <p>Номер студенческого билета: {student.id}</p>
            <p>Баллы: {student.points}</p>
            <p>Пропуски: {student.absences}</p>
            <p>Номер группы: {student.groupNumber}</p>
            <p>Год поступления: {student.admissionYear}</p>
            <p>Номер телефона: {student.phoneNumber}</p>
            <p>Email: {student.email}</p>
        </div>
    );
};

export default StudentDetailPage;
