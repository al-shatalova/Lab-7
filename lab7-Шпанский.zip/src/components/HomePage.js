// HomePage.js
import React from 'react';

const HomePage = () => {
    // Define the schedule for each day
    const schedule = [
        {
            day: 'Понедельник',
            classes: [
                { time: '9:00 - 10:30', subject: 'Математика' },
                { time: '11:00 - 12:30', subject: 'Физика' },
                { time: '14:00 - 15:30', subject: 'Английский' },
                // Add more classes if needed
            ],
        },
        {
            day: 'Вторник',
            classes: [
                { time: '10:00 - 11:30', subject: 'Литература' },
                { time: '13:00 - 14:30', subject: 'Биология' },
                // Add more classes if needed
            ],
        },
        {
            day: 'Среда',
            classes: [
                { time: '8:30 - 10:00', subject: 'Информатика' },
                { time: '12:00 - 13:30', subject: 'География' },
                { time: '15:00 - 16:30', subject: 'История' },
                // Add more classes if needed
            ],
        },
        {
            day: 'Четверг',
            classes: [
                { time: '9:30 - 11:00', subject: 'Физкультура' },
                // Add more classes if needed
            ],
        },
        {
            day: 'Пятница',
            classes: [
                { time: '10:30 - 12:00', subject: 'Химия' },
                { time: '14:30 - 16:00', subject: 'Иностранный язык' },
                // Add more classes if needed
            ],
        },
    ];

    return (
        <div>
            <h1>Расписание на неделю</h1>
            <table className="table">
                <thead>
                <tr>
                    <th>Время</th>
                    {schedule.map((day) => (
                        <th key={day.day}>{day.day}</th>
                    ))}
                </tr>
                </thead>
                <tbody>
                {Array.from({ length: 4 }, (_, index) => (
                    <tr key={index}>
                        <td>{`Пара ${index + 1}`}</td>
                        {schedule.map((day) => (
                            <td key={day.day}>
                                {day.classes[index] ? (
                                    <div>
                                        <div>{day.classes[index].time}</div>
                                        <div>{day.classes[index].subject}</div>
                                    </div>
                                ) : (
                                    // Placeholder if no class at this time
                                    <div>---</div>
                                )}
                            </td>
                        ))}
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
};

export default HomePage;
