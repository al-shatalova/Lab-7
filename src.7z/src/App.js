import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Header';
import MainTable from './MainTable';
import InfoPage from './InfoPage';

const App = () => {
    const [students, setStudents] = useState([
        { id: 1, second_name:'Гусев', name: 'Алексей', age: 20, aver_mark: 4.8},
        { id: 2, second_name:'Сысоев', name: 'Арсений', age: 21, aver_mark: 5 },
    ]);

    const handleDelete = (studentId) => {
        setStudents(students.filter((student) => student.id !== studentId));
    };

    const handleAdd = (newStudent) => {
        setStudents([...students, { id: students.length + 1, ...newStudent }]);
    };

    return (
        <Router>
            <div>
                <Header />
                <Routes>
                    <Route
                        path="/"
                        element={<MainTable students={students} onDelete={handleDelete} onAdd={handleAdd} />}
                    />
                    <Route path="/info" element={<InfoPage />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
