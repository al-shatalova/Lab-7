import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import MainTable from './components/MainTable';
import InfoPage from './components/InfoPage';

const App = () => {
    const [students, setStudents] = useState([
        {id: 1, second_name:'Кувакин', name: 'Илья', age: 20, aver_mark: 5},
        {id: 2, second_name:'Миронов', name: 'Сергей', age: 21, aver_mark: 3.5},
        {id: 3, second_name:'Трубина', name: 'Светлана', age: 15, aver_mark: 4.75},
        {id: 4, second_name:'Федоренко', name: 'Тимофей', age: 20, aver_mark: 4},
        {id: 5, second_name:'Донскова', name: 'Грета', age: 17, aver_mark: 5},
        {id: 6, second_name:'Олейников', name: 'Александр', age: 15, aver_mark: 5},
        {id: 7, second_name:'Мартышина', name: 'Елизавета', age: 13, aver_mark: 5},
        {id: 8, second_name:'Перов', name: 'Андрей', age: 20, aver_mark: 5},
        {id: 9, second_name:'Парамонов', name: 'Денис', age: 20, aver_mark: 4.2},
        {id: 10, second_name:'Гослинг', name: 'Райан', age: 30, aver_mark: 3.8},
        {id: 11, second_name:'Бейтман', name: 'Патрик', age: 27, aver_mark: 4.9},
        {id: 12, second_name:'Барбоскин', name: 'Барни', age: 1.5, aver_mark: 5},
        {id: 13, second_name:'Барбоскин', name: 'Кипер', age: 0.9, aver_mark: 5},
        {id: 14, second_name:'Дёрден', name: 'Тайлер', age: 29, aver_mark: 0}


    ]);

    const handleDelete = (studentId) => {
        setStudents(students.filter((student) => student.id !== studentId));
    };

    const handleAdd = (newStudent) => {
        setStudents([...students, { id: students.length + 1, ...newStudent }]);
    };

    return (
        <Router>
            <div>
                <Header />

                <Routes>
                    <Route
                        path="/"
                        element={<MainTable students={students} onDelete={handleDelete} onAdd={handleAdd} />}
                    />
                    <Route path="/info" element={<InfoPage />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
