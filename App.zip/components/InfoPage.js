import React from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';

const InfoPage = () => {
    return (
        <Container>
            <h2 className="mt-4">Немного о нас</h2>

            <Row className="mt-4">
                <Col md={6}>
                    <h3>Финансовый Университет при Правительстве РФ</h3>
                    <p>
                        В нашем прекрасном университете учатся и преподают прекрасные студенты и преподаватели! 
                        Мы - ведущий экономический университет России!
                        Страсть к знаниям и любимому делу питает и вдохновляет нас!
                        Давайте получим эти баллы!
                    </p>
                </Col>

                <Col md={6}>
                    <h3>Контакты</h3>
                    <p>Email: academy@fa.ru</p>
                    <p>Телефон: +7 495 249-5249</p>
                    <p>Адрес: г.Москва, пр-кт Ленинградский, д. 49/2</p>
                </Col>
            </Row>

            <h2 className="mt-4">Управленческий состав</h2>

            <Row className="mt-4">
                <Col md={4} className="mb-4">
                    <Image
                        src="https://veorus.ru/img/ves-2023/speakers/prokofiev.jpg"
                        className="mb-3"
                        width={250}
                        height={250}
                    />
                    <h4>Прокофьев Станислав</h4>
                    <h4>Евгеньевич</h4>
                    <p>Ректор</p>
                </Col>

                <Col md={4} className="mb-4">
                    <Image
                        src="https://www.finversia.ru/site/public/files/1/569-eskindarov.jpg"
                        className="mb-3"
                        width={250}
                        height={250}
                    />
                    <h4>Эскиндаров Михаил</h4>
                    <h4>Абдурахманович</h4>
                    <p>Президент</p>
                </Col>

                <Col md={4} className="mb-4">
                    <Image
                        src="https://sympozium-cemi.ru/wp-content/uploads/2022/03/fedotova.jpg"
                        className="mb-3"
                        width={250}
                        height={250}
                    />
                    <h4>Федотова Марина</h4>
                    <h4>Алексеевна</h4>
                    <p>Заместитель научного руководителя</p>
                </Col>
            </Row>
        </Container>
    );
};

export default InfoPage;
