import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

const AddStudentModal = ({ show, handleClose, onAdd }) => {
    const [newStudent, setNewStudent] = useState({second_name:'', name: '', age: '' , aver_mark: ''});

    const handleAddClick = () => {
        onAdd(newStudent);
        setNewStudent({second_name:'', name: '', age: '' , aver_mark: ''});
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Добавить студента</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group controlId="formSecondName">
                        <Form.Label>Фамилия</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите фамилию"
                            value={newStudent.second_name}
                            onChange={(e) => setNewStudent({ ...newStudent, second_name: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group className={'py-2'} controlId="formName">
                        <Form.Label>Имя</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите имя"
                            value={newStudent.name}
                            onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group controlId="formAge">
                        <Form.Label>Возраст</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите возраст"
                            value={newStudent.age}
                            onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
                        />
                    </Form.Group>
                    <Form.Group className={'py-2'} controlId="formAver_mark">
                        <Form.Label>Средний балл</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Введите средний балл"
                            value={newStudent.aver_mark}
                            onChange={(e) => setNewStudent({ ...newStudent, aver_mark: e.target.value })}
                        />
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button className={'btn btn-secondary'} variant="secondary" onClick={handleClose}>
                    Закрыть
                </Button>
                <Button className={'btn btn-success'} variant="danger" onClick={handleAddClick}>
                    Добавить
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default AddStudentModal;
