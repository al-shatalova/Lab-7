import React, {useState} from 'react';
import {BrowserRouter as Router, Route, Link, Routes} from 'react-router-dom';
import StudentList from './components/StudentList';
import AddStudentForm from './components/AddStudentForm';
import AboutPage from './AboutPage';
import ContactPage from './ContactPage';
// App.js
import './App.css';

const App = () => {
    const [students, setStudents] = useState([
        {
            id: 1,
            name: 'Анпилов Кирилл',
            grade: '0',
            selected: false,
        },
        {
            id: 2,
            name: 'Фархутдинов Айдар Зинфирович',
            grade: '0',
            selected: false,
        },
        // Другие студенты...
    ]);

    const [formData, setFormData] = useState({
        name: '',
        grade: '',
    });

    const [filterText, setFilterText] = useState('');

    const handleInputChange = (e) => {
        const {name, value} = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };


    const toggleSelect = (id) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === id ? {...student, selected: !student.selected} : student
            )
        );
    };

    const deleteSelected = () => {
        const updatedStudents = students.filter((student) => !student.selected);
        setStudents(updatedStudents);
    };

    const handleFilterTextChange = (e) => {
        setFilterText(e.target.value);
    };

    const filteredStudents = students.filter(
        (student) =>
            student.name.toLowerCase().includes(filterText.toLowerCase()) ||
            student.grade.toLowerCase().includes(filterText.toLowerCase())
    );
    const addStudent = () => {
        if (formData.name.trim() === '' || formData.grade.trim() === '') {
            alert('Заполните все поля формы.');
            return;
        }

        const newStudent = {
            id: new Date().getTime(),
            name: formData.name,
            grade: formData.grade,
            selected: false,
        };

        setStudents([...students, newStudent]);

        setFormData({
            name: '',
            grade: '',
        });
    };

    return (
        <Router>
            <div>
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Главная</Link>
                        </li>
                        <li>
                            <Link to="/about">О компании</Link>
                        </li>
                        <li>
                            <Link to="/contact">Контакты</Link>
                        </li>
                    </ul>
                </nav>

                <hr/>

                <Routes>
                    <Route
                        path="/"
                        element={
                            <div>
                                <h1>Журнал университетской группы</h1>

                                <form>
                                    <label>
                                        Фильтр:
                                        <input
                                            type="text"
                                            placeholder="Введите текст для фильтрации"
                                            value={filterText}
                                            onChange={handleFilterTextChange}
                                        />
                                    </label>
                                </form>
                                <StudentList
                                    students={filteredStudents}
                                    toggleSelect={toggleSelect}
                                    deleteSelected={deleteSelected}
                                />
                                <AddStudentForm
                                    formData={formData}
                                    handleInputChange={handleInputChange}
                                    addStudent={addStudent}
                                />
                            </div>
                        }
                    />

                    <Route path="/about" element={<AboutPage/>}/>
                    <Route path="/contact" element={<ContactPage/>}/>
                </Routes>
            </div>
        </Router>
    );
};

export default App;