// ContactPage.js
import React from 'react';

const ContactPage = () => {
    return (
        <div>
            <h1>Контакты</h1>
            <p>88005553535</p>
        </div>
    );
};

export default ContactPage;
