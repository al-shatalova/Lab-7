// StudentList.js
import React from 'react';

const StudentList = ({ students, toggleSelect, deleteSelected }) => {
    return (
        <div>
            <h2>Список студентов:</h2>

            <table>
                <thead>
                <tr>
                    <th>№</th>
                    <th>ФИО</th>
                    <th>Балл</th>
                    <th>Выделить</th>
                </tr>
                </thead>
                <tbody>
                {students.map((student, index) => (
                    <tr key={student.id} style={{ backgroundColor: student.selected ? '#aaf' : 'transparent' }}>
                        <td>{index + 1}</td>
                        <td>{student.name}</td>
                        <td>{student.grade}</td>
                        <td>
                            <input type="checkbox" checked={student.selected} onChange={() => toggleSelect(student.id)} />
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <button onClick={deleteSelected}>Удалить выделенных студентов</button>
        </div>
    );
};

export default StudentList;
