// AddStudentForm.js
import React from 'react';
import './AddStudentForm.css';  // Подключаем стили
const AddStudentForm = ({ formData, handleInputChange, addStudent }) => {
    return (
        <form>
            <label>
                Имя студента:
                <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                />
            </label>

            <label>
                Балл:
                <input
                    type="text"
                    name="grade"
                    value={formData.grade}
                    onChange={handleInputChange}
                />
            </label>
            <button type="button" onClick={addStudent}>
                Добавить студента
            </button>
        </form>
    );
};

export default AddStudentForm;
