import { useState } from 'react'
import './App.css'
import StopWatch from './pages/StopWatch';
import CatFriends from './pages/catfriends';
import Accordion from './pages/Accordion';

function App() {
  const [isStopwatchChanged, setIsStopwatchChanged] = useState(false);
  const handleStopwatchChange = (changeChildrenState) => {
    changeChildrenState.preventDefault()
    if (changeChildrenState) {
      setIsStopwatchChanged(true);
      console.log(isStopwatchChanged);
    }
  };
  return (
    <div className='container-class'>
      
      <StopWatch onChange={handleStopwatchChange} />
      <CatFriends></CatFriends>
      <Accordion change={isStopwatchChanged} onChange={(event) => event.preventDefault()}/>

    </div>
  )
}

export default App
