import { useState, useRef } from 'react';

export default function Stopwatch({ onChange }) {
  const [startTime, setStartTime] = useState(null);
  const [now, setNow] = useState(null);
  const intervalRef = useRef(null);
  const [endTime, setEndTime] = useState();

  function handleStart() {
    setStartTime(Date.now());
    setNow(Date.now());

    clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setNow(Date.now());
    }, 1);
  }

  function handleStop() {
    clearInterval(intervalRef.current);
  }

  let secondsPassed = 0;
  if (startTime != null && now != null) {
    secondsPassed = (now - startTime) / 1000;
  }


  if (endTime !== null && secondsPassed >= endTime){
    handleStop()
    onChange(true)
  }

  function handleEndTimeChange(event) {
    setEndTime(parseFloat(event.target.value));
  }

  return (
    <>
      <h1>Time passed: {secondsPassed.toFixed(3)}</h1>
      <div className='timer-buttons-block'>
        <button  type="button" className="btn btn-success" onClick={handleStart}>
          Start
        </button>
        <button type="button" className="btn btn-danger" onClick={handleStop}>
          Stop
        </button>
        <div>
          <label htmlFor="endTimeInput">Выключить через:</label>
          <input
            type="number"
            id="endTimeInput"
            value={endTime || ''}
            onChange={handleEndTimeChange}
            placeholder="Введите время в секундах:"
          />
        </div>
      </div>
    </>
  );
}