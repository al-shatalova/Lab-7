import { useRef } from 'react';

export default function CatFriends() {
  const firstCatRef = useRef(null);
  const secondCatRef = useRef(null);
  const thirdCatRef = useRef(null);

  function handleScrollToFirstCat() {
    firstCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  function handleScrollToSecondCat() {
    secondCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  function handleScrollToThirdCat() {
    thirdCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  return (
    <>
      <nav>
        <button type="button" class="btn btn-info" onClick={handleScrollToFirstCat}>
          Tom
        </button>
        <button type="button" class="btn btn-info" onClick={handleScrollToSecondCat}>
          Maru
        </button>
        <button  type="button" class="btn btn-info" onClick={handleScrollToThirdCat}>
          Jellylorum
        </button>
      </nav>
      <div className='div-slider'>
        <ul>
          <li>
            <img
              src="https://masterpiecer-images.s3.yandex.net/db52a7a770b411eebf043abd0be4d755:upscaled"
              alt="Tom"
              ref={firstCatRef}
            />
          </li>
          <li>
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGQxf1Kv1_Ac0gKhcgwB97yyiJBaQwocK2Eg&usqp=CAU"
              alt="Maru"
              ref={secondCatRef}
            />
          </li>
          <li>
            <img
              src="https://krasivosti.pro/uploads/posts/2022-08/1661434819_1-krasivosti-pro-p-sobaki-s-kvadratnoi-mordoi-vkontakte-1.jpg"
              alt="Jellylorum"
              ref={thirdCatRef}
            />
          </li>
        </ul>
      </div>
    </>
  );
}
