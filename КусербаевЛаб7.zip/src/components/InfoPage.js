import React from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';

const InfoPage = () => {
    return (
        <Container>
            <h2 className="mt-4">Немного о нас</h2>

            <Row className="mt-4">
                <Col md={6}>
                    <h3>Здравствуйте</h3>
                    <p>
                        Добро пожаловать на наш сайт! Мы рады, что вы решили воспользоваться нашими технологиями.
                        Мы долго и упорно трудились для вашего удобства. Используйте наши технологии, если они подходят
                        под ваш проект. Все права защищены.
                    </p>
                </Col>

                <Col md={6}>
                    <h3>Контакты</h3>
                    <p>Email: karim@kuserbaev.ru</p>
                    <p>Телефон: +7 906 839-27-31</p>
                    <p>Адрес: г. Москва, Красная Площадь, д.1</p>
                </Col>
            </Row>

            <h2 className="mt-4">Команда</h2>

            <Row className="mt-4">
                <Col md={4} className="mb-4">
                    <Image
                        src="https://m.media-amazon.com/images/I/81hiJLs5wjL._UF894,1000_QL80_.jpg"
                        alt="челик"
                        roundedCircle
                        className="mb-3"
                        width={250}
                        height={250}
                    />
                    <h4>Кусербаев Карим</h4>
                    <p>Позиция: Разработчик</p>
                    <p>Люблю милкшейк и красивый код.</p>
                </Col>

            </Row>
        </Container>
    );
};

export default InfoPage;
