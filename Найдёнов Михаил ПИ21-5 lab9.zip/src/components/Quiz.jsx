// src/components/Quiz.js
import React, { useState } from 'react';
import Question from './Question';
import dataSet from '../data';

const Quiz = ({ playerName, onStartQuiz }) => {
  const [score, setScore] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const questions = dataSet();

  const handleAnswer = (isCorrect) => {
    if (isCorrect) {
      setScore(score + 1);
    }

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
        alert(`Викторина пройдена! ${playerName}, ваши очки: ${score}/${questions.length}`);

    }
  };

  return (
    <div>
      {currentQuestionIndex < questions.length ? (
        <Question
          question={questions[currentQuestionIndex].question}
          options={questions[currentQuestionIndex].answers}
          answer={questions[currentQuestionIndex].rightIndex}
          onAnswer={handleAnswer}
        />
      ) : null}
    </div>
  );
};

export default Quiz;
