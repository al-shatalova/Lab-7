// src/components/Question.js
import React, { useState } from 'react';

const Question = ({ question, options, onAnswer, answer }) => {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionChange = (option) => {
    setSelectedOption(option);
  };

  const handleSubmit = () => {
    const isCorrect = selectedOption === options[answer];
    onAnswer(isCorrect);
  };

  return (
    <div className='question-sect'>
      <h2>{question}</h2>
      <ul>
        {options.map((option, index) => (
          <li key={index}>
            <label>
              <input
                type="radio"
                name="options"
                value={option}
                checked={selectedOption === option}
                onChange={() => handleOptionChange(option)}
              />
              {option}
            </label>
          </li>
        ))}
      </ul>
      <button type="button" className="btn btn-success" onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default Question;
