// src/App.js
import React, { useState } from 'react';
import Quiz from './components/Quiz';

function App() {
  const [playerName, setPlayerName] = useState('');
  const [quizStarted, setQuizStarted] = useState(false);

  const handleStartQuiz = () => {
    if (playerName.trim() === '') {
      alert('введите свое имя и фамилию');
      return;
    }
    setQuizStarted(true);
  };

  return (
    <div className="App">
      {!quizStarted ? (
        <div className='login-page'>
          <h1>Добро пожаловать в приложение для викторины</h1>
          <label>
            Имя и фамилию:
            <input type="text" value={playerName} onChange={(e) => setPlayerName(e.target.value)} />
          </label>
          <button type="button" className="btn btn-success" onClick={handleStartQuiz}>Начать викторину</button>
        </div>
      ) : (
        <Quiz playerName={playerName} onStartQuiz={handleStartQuiz} />
      )}
    </div>
  );
}

export default App;
