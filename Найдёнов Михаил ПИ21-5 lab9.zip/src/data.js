const dataSet = () => {
    return [
        {question:'React - это библиотека JavaScript для создания ___.', answers: ['Баз данных', 'Пользовательских интерфейсов', 'Платформ для проектирования', 'Файлов'], rightIndex: 1},
        {question:'Пользовательский интерфейс, разработанный с помощью React, состоит из небольших и изолированных фрагментов кода, называемых ___.', answers: ['Компоненты', 'Хуки', 'Функции', 'Классы'], rightIndex: 0},
        {question:'Компонент React принимает параметры, называемые ___?', answers: ['Атрибуты', 'События', 'Реквизиты', 'Наследники'], rightIndex: 2},
        {question:'Для написания HTML в react мы используем ___?', answers: ['React.CreateElement()', 'HTTP', 'XML', 'JSX'], rightIndex: 3},
        {question:'JSX расшифровывается как ___?', answers: ['JavaScript Extension', 'JavaScript Extreme', 'JavaScript XML', 'JavaScript XScript'], rightIndex: 2},
    ]
}
export default dataSet



