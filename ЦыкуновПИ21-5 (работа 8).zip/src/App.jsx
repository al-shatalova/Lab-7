import Stopwatch from './Stopwatch.jsx';
import Accordion from './Accordion.jsx';
import CatFriends from './CatFriends.jsx';
import './App.css';

export default function App() {
  return (
    <>
      <Stopwatch />
      <Accordion />
      <CatFriends />
    </>
  );
}
