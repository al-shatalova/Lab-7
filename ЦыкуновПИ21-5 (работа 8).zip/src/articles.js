export default [
  {
    id: 1,
    title: 'Название 1',
    text: 'Текст статьи 1'
  },
  {
    id: 2,
    title: 'Название 2',
    text: 'Текст статьи 2'
  },
]