import { useRef } from 'react';

export default function CatFriends() {
  const firstCatRef = useRef(null);
  const secondCatRef = useRef(null);
  const thirdCatRef = useRef(null);

  function handleScrollToFirstCat() {
    firstCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  function handleScrollToSecondCat() {
    secondCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  function handleScrollToThirdCat() {
    thirdCatRef.current.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }

  return (
    <div className="container slider">
      <nav>
        <button onClick={handleScrollToFirstCat}>
          Спереди
        </button>
        <button onClick={handleScrollToSecondCat}>
          Под углом
        </button>
        <button onClick={handleScrollToThirdCat}>
          Сравнение
        </button>
      </nav>
      <div>
        <ul className="scroll-list">
          <li>
            <img
              src="https://i.ebayimg.com/00/s/OTAzWDE0MTI=/z/X4sAAOSwo5FjKwap/$_57.JPG?set_id=8800005007"
              ref={firstCatRef}
            />
          </li>
          <li>
            <img
              src="https://static.insales-cdn.com/files/1/59/21372987/original/macbook-pro-2021-cnet-review-12.jpg"
              ref={secondCatRef}
            />
          </li>
          <li>
            <img
              src="https://cdn.mos.cms.futurecdn.net/H57m7yAMjhGFQ265z2vVS9.jpg"
              ref={thirdCatRef}
            />
          </li>
        </ul>
      </div>
    </div>
  );
}
