import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-light text-center p-3 mt-auto">
            <p>&copy; 2023 Мельник Геннадий ПИ21-2.</p>
        </footer>
    );
}

export default Footer;
