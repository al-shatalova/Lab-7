
import React from 'react';
import { Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
const HomePage = () => {

    const schedule = [
        {
            day: 'Понедельник',
            classes: [
                { time: '8:30 - 10:00', subject: 'Философия', type: 'Семинар', teacher: 'Робертовна О.Р.', location: '4-ый вешняковский проезж Ауд. 1201'},
                { time: '10:10 - 11:40', subject: 'Иностранный язык в професссиальной сфере', type: 'Лекции', teacher: 'Харитонова О.Р.', location: '4-ый вешняковский проезж Ауд. 1251' },
                { time: '11:50 - 13:20', subject: 'Deep f***ing learninr', type: 'Семинар', teacher: 'Семеновна О.Р.', location: '4-ый вешняковский проезж Ауд. 1301' },

            ],
        },
        {
            day: 'Вторник',
            classes: [
                { time: '10:00 - 11:30', subject: 'Java', type: 'Семинар', teacher: 'Хусинова А.Х.', location: '4-ый вешняковский проезж Ауд. 2201' },
                { time: '11:40 - 13:20', subject: 'NLP', type: 'Лекции' , teacher: 'Колчак О.Р.', location: '4-ый вешняковский проезж Ауд. 3201'},

            ],
        },
        {
            day: 'Среда',
            classes: [
                { time: '8:30 - 10:00', subject: 'BIS(kot v banke)', type: 'Семинар', teacher: 'Толстой О.Р.', location: '4-ый вешняковский проезж Ауд. 3251' },
                { time: '10:10 - 11:40', subject: '1C', type: 'Лекции', teacher: 'Харит О.Р.', location: '4-ый вешняковский проезж Ауд. 2261' },
                { time: '11:50 - 13:20', subject: 'Inzheneriya', type: 'Лекции', teacher: 'Ханачевская О.Р.', location: '4-ый вешняковский проезж Ауд. 1231' },

            ],
        },
        {
            day: 'Четверг',
            classes: [
                { time: '8:30 - 10:00', subject: 'OVP', type: 'Семинар', teacher: 'Робертоовна О.Р.', location: '4-ый вешняковский проезж Ауд. 1201' },

            ],
        },
        {
            day: 'Пятница',
            classes: [
                { time: '14:00 - 15:30', subject: 'Sistemnoe programmirovanie', type: 'Семинар', teacher: 'Робертоовна О.Р.', location: '4-ый вешняковский проезж Ауд. 1201' },
                { time: '15:40 - 17:10', subject: 'Yazik R', type: 'Семинар', teacher: 'Робертоовна О.Р.', location: '4-ый вешняковский проезж Ауд. 1201' },

            ],
        },
    ];

    return (
        <div>
            <Typography variant="h4" gutterBottom>
                Расписание на неделю
            </Typography>
            {schedule.map((day) => (
                <div key={day.day}>
                    <Typography variant="h6">
                        День: {day.day}
                    </Typography>
                    <TableContainer component={Paper}>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Пара</TableCell>
                                    <TableCell>Время</TableCell>
                                    <TableCell>Предмет</TableCell>
                                    <TableCell>Тип</TableCell>
                                    <TableCell>Преподаватель</TableCell>
                                    <TableCell>Место</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {day.classes.map((cls, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{`Пара ${index + 1}`}</TableCell>
                                        <TableCell>{cls.time}</TableCell>
                                        <TableCell>{cls.subject}</TableCell>
                                        <TableCell>{cls.type}</TableCell>
                                        <TableCell>{cls.teacher}</TableCell>
                                        <TableCell>{cls.location}</TableCell>
                                    </TableRow>
                                ))}
                                {Array.from({ length: 4 - day.classes.length }, (_, index) => (
                                    <TableRow key={`empty-${index}`}>
                                        <TableCell>{`Пара ${day.classes.length + index + 1}`}</TableCell>
                                        <TableCell>---</TableCell>
                                        <TableCell>---</TableCell>
                                        <TableCell>---</TableCell>
                                        <TableCell>---</TableCell>
                                        <TableCell>---</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
            ))}
        </div>
    );

};

export default HomePage;
