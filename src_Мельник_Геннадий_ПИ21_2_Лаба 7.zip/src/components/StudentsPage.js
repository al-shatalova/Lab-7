import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { studentsData } from './studentsData';
import { Typography, Checkbox ,Paper, Table, TableBody, TableCell, TableHead, TableRow, TextField, Button, Box } from '@mui/material';
const StudentsPage = () => {
    const [students, setStudents] = useState(studentsData);

    const [filter, setFilter] = useState('');
    const [selectedStudents, setSelectedStudents] = useState([]);
    const [newStudentName, setNewStudentName] = useState('');
    const [newStudentPoints, setNewStudentPoints] = useState('');
    const [newStudentAbsences, setNewStudentAbsences] = useState('');

    const toggleSelect = (studentId) => {
        if (selectedStudents.includes(studentId)) {
            setSelectedStudents(selectedStudents.filter(id => id !== studentId));
        } else {
            setSelectedStudents([...selectedStudents, studentId]);
        }
    };

    const deleteStudent = (id) => {
        const updatedStudents = students.filter((student) => student.id !== id);
        setStudents(updatedStudents);
        setSelectedStudents(selectedStudents.filter(studentId => studentId !== id));
    };

    const addStudent = () => {

        if (newStudentName.trim() === '' || isNaN(newStudentPoints) || isNaN(newStudentAbsences)) {
            alert('Введите корректную информацию о студенте.');
            return;
        }


        const newStudent = {
            id: students.length + 1,
            fullName: newStudentName.trim(),
            points: parseInt(newStudentPoints, 10),
            absences: parseInt(newStudentAbsences, 10),
        };


        setStudents([...students, newStudent]);


        setNewStudentName('');
        setNewStudentPoints('');
        setNewStudentAbsences('');
    };

    const filteredStudents = students.filter(
        (student) => student.fullName.toLowerCase().includes(filter.toLowerCase())
    );

    const deleteSelectedStudents = () => {
        const updatedStudents = students.filter((student) => !selectedStudents.includes(student.id));
        setStudents(updatedStudents);
        setSelectedStudents([]);
    };

    useEffect(() => {

        const script = document.createElement('script');
        script.src = 'https://www.kryogenix.org/code/browser/sorttable/sorttable.js';
        script.async = true;
        document.head.appendChild(script);


        return () => {
            document.head.removeChild(script);
        };
    }, []);
    return (
        <Box style={{ padding: '20px' }}>
            <Helmet>
                <script src="https://www.kryogenix.org/code/browser/sorttable/sorttable.js"></script>
            </Helmet>
            <Typography variant="h4" gutterBottom>
                Страница студентов
            </Typography>
            <Box component="form" style={{ marginBottom: '20px' }}>
                <TextField
                    label="Имя и Фамилия"
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    margin="normal"
                    fullWidth
                />
                <TextField
                    label="Баллы"
                    value={newStudentPoints}
                    onChange={(e) => setNewStudentPoints(e.target.value)}
                    margin="normal"
                    fullWidth
                />
                <TextField
                    label="Пропуски"
                    value={newStudentAbsences}
                    onChange={(e) => setNewStudentAbsences(e.target.value)}
                    margin="normal"
                    fullWidth
                />
                <Button variant="contained" color="primary" onClick={addStudent} style={{ marginTop: '20px' }}>
                    Добавить студента
                </Button>
            </Box>
            <TextField
                label="Фильтр по имени или фамилии"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                margin="normal"
                fullWidth
            />
            <Button
                variant="contained"
                color="secondary"
                onClick={deleteSelectedStudents}
                disabled={selectedStudents.length === 0}
                style={{ marginTop: '20px', marginBottom: '20px' }}
            >
                Удалить выделенных студентов
            </Button>
            <Paper>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Выбор</TableCell>
                            <TableCell>ID</TableCell>
                            <TableCell>Имя и Фамилия</TableCell>
                            <TableCell>Баллы</TableCell>
                            <TableCell>Пропуски</TableCell>
                            <TableCell>Действия</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {filteredStudents.map((student) => (
                            <TableRow key={student.id} selected={selectedStudents.includes(student.id)}>
                                <TableCell padding="checkbox">
                                    <Checkbox
                                        checked={selectedStudents.includes(student.id)}
                                        onChange={() => toggleSelect(student.id)}
                                    />
                                </TableCell>
                                <TableCell>{student.id}</TableCell>
                                <TableCell>
                                    <Link to={`/students/${student.id}`}>
                                        {student.fullName}
                                    </Link>
                                </TableCell>
                                <TableCell>{student.points}</TableCell>
                                <TableCell>{student.absences}</TableCell>
                                <TableCell>
                                    <Button
                                        variant="contained"
                                        color="secondary"
                                        onClick={() => deleteStudent(student.id)}
                                    >
                                        Удалить
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Paper>
        </Box>
    );
};

export default StudentsPage;
