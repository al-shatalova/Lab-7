import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <AppBar position="static" color="default">
            <Toolbar>
                <Typography variant="h6" color="inherit" component={Link} to="/" style={{ textDecoration: 'none', flexGrow: 1 }}>
                    Тут должно быть что-то красивое, но мне лень
                </Typography>
                <Button color="inherit" component={Link} to="/students">
                    Список прогульщиков
                </Button>
            </Toolbar>
        </AppBar>
    );
}

export default Header;
