// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import StudentsPage from './components/StudentsPage';
import StudentDetailPage from './components/StudentDetailPage';

const App = () => {
    return (
        <div className="d-flex flex-column min-vh-100">
            <Router>
                <Header />
                <div className="container mt-4 flex-grow-1">
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/students" element={<StudentsPage />} />
                        <Route path="/students/:id" element={<StudentDetailPage />} />
                    </Routes>
                </div>
                <Footer />
            </Router>
        </div>
    );
}

export default App;
