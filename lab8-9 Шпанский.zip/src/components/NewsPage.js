import React, { useRef } from 'react';
import articlesData from './articlesData';
import ArticleCard from '../components/ArticleCard';
import TomatoTimer from '../components/TomatoTimer';
import 'bootstrap/dist/css/bootstrap.min.css';
import './ArticleCard.css';

const NewsPage = () => {
    const aiRef = useRef(null);
    const blockchainRef = useRef(null);
    const webDevRef = useRef(null);
    const cyberSecurityRef = useRef(null);
    const edTechRef = useRef(null);

    const scrollToRef = (ref) => {
        ref.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    return (
        <div>
            <TomatoTimer />
            <nav className="slider-buttons-container">
                <button className="slider-button" onClick={() => scrollToRef(aiRef)}>Искусственный интеллект</button>
                <button className="slider-button" onClick={() => scrollToRef(blockchainRef)}>Блокчейн</button>
                <button className="slider-button" onClick={() => scrollToRef(webDevRef)}>Веб-разработка</button>
                <button className="slider-button" onClick={() => scrollToRef(cyberSecurityRef)}>Кибербезопасность</button>
                <button className="slider-button" onClick={() => scrollToRef(edTechRef)}>Информационные технологии в образовании</button>
            </nav>
            <section ref={aiRef}>
                <h2>Искусственный интеллект</h2>
                <div className="d-flex justify-content-around">
                    {articlesData.ai.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </div>
            </section>
            <section ref={blockchainRef}>
                <h2>Блокчейн</h2>
                <div className="d-flex justify-content-around">
                    {articlesData.blockchain.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </div>
            </section>
            <section ref={webDevRef}>
                <h2>Веб-разработка</h2>
                <div className="d-flex justify-content-around">
                    {articlesData.webDev.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </div>
            </section>
            <section ref={cyberSecurityRef}>
                <h2>Кибербезопасность</h2>
                <div className="d-flex justify-content-around">
                    {articlesData.cyberSecurity.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </div>
            </section>
            <section ref={edTechRef}>
                <h2>Информационные технологии в образовании</h2>
                <div className="d-flex justify-content-around">
                    {articlesData.edTech.map((article, index) => (
                        <ArticleCard key={index} {...article} />
                    ))}
                </div>
            </section>
        </div>
    );
};

export default NewsPage;
