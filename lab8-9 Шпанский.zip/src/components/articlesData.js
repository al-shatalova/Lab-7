const articlesData = {
    ai: [
        {
            title: "Прорывы в области машинного обучения",
            description: "Изучение последних достижений и методов в машинном обучении.",
            imageUrl: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgVFRUYGBYaGR0YGhocHBgaGBoYGBoaHhoYGRgcIS4lHB4rHxoZJjgmKy8xNTU1GiQ7QDs1Py40NTEBDAwMEA8QHxISHzQrJCs1NDQ0NDQ0NjQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAIDBQYBBwj/xAA/EAACAQIEAwYDBgQFAwUAAAABAhEAAwQSITEFQWEGIlFxgZETMqFCUrHB0fAHFHKCIzNisuGSwvEVQ3OTov/EABoBAAMBAQEBAAAAAAAAAAAAAAECAwQABQb/xAAnEQACAgICAQMEAwEAAAAAAAAAAQIRITEDEkETIlEEYXGBIzKxFP/aAAwDAQACEQMRAD8A8lzVJZeKHmpsOsmtSk7JvRPcuGPAVIEkA1Jj1hBUdtu6Kd7ySTtWhqWM0xyqEtyo3BiWbWh7tmDM0GsWMpZpkFOWmmnrSjM7FONcDUqKFYhTwKlwWCuXWy20Zz4KCY8zy9auV7JYuJNsDoWWfpNEDKIV0CjcVwq9b+dCB47j3FCAUUI2dFdApRTgKdCMVOAropAUyJsks3CpBG4q24bxNxcDElukwdBMA8tBVQBU+Fu5GDRI108wR+dMickmTsGuuTm1J1LaQJ5mpWttbggqx10BDKyGNwOR1oQusnKSJ9I9q4bfPQ+RE+24phKDf5hAZCMTyDMCi6fdiT5E+9CyK4HIO/hvB+hp0gnb8v8AiimK1RxjqaVSsgOtQU3ZoCyKKRFcmug0bTGGkU0ipQKcxM/s11HWDEVyKJCTy9q4bP7NK4h7IHrkVI9sjemEUtDJjw1KuUq4FFDFPsb0w1JYJnSsS2eo9FpxED4axUKWyEBin45DkUmordw5QCaq3khFe39k3DdWah75OYii8Ae83OhsTbJMgVz0cn7mCmuqa4RSqZYeCK1/ZTsXcxDh7yOlka6gqz9FnUD/AFe3R/8ADjgi3rzXnXMlqMoOxuHUE+OUCfMrXsmAYAyaWUq0dVlbgeHW7SBLaKqjkoH18TXcRbFav+XRoYqCfHn7is72jw+XVZA6TU4ytnSjSM3j7CkGRWG4vwlCSV7p+nqK0+LxLfePuaqrylt9avFUZ5Mxdy0VJVhBFcFa7ivAC4VgYaNJGjdJrJRVY5EbOiugVwCngUyEbFFIU6KUUyEYgK7Siu0wolp5ptKKIGiwwYlSOv3VY6QdJMj0qMWQTyPPQsD9Vj6VzBYfOY+zPeOggGOZ0HrU9hYvOACYDxuPlVtdJ105ULBQC9sb6geh321B8KaU0mQd+eunTfnVrhxN1Bl3txEaR8PoZkflVc9oqxDKR4SCOfUVyGIkOo86lfeoV3FEGCTJjUx6/lVEJLZNh7RknaBmpFWYjxplm6wJAP7FEYa7uDvMz1p0kyUrWQfGIQFkcqCIq3x5BAIkcvaqlqSSyPxO4jYpV2aVJRUoYpKxG1dSuNWE9Ule+xEEyK4LhqMV2utnUgnDYooT1qZ8VI2/CgRRjoQBNOpOicoxsHIJroFT2wTUgtt4UEjm6NAMU1rh1q2hKtiLrs+WQSgbJEjlCGrPsOLiu4W66E2rj6GUDgSCUPdI35VXWbyqmCdzCLnVjyAa7cVm9AxPpR3BnJuBQMhdlw7g6FWd1Vk8wAx8h1oVsDkeg9meF37qpexeIuXCwDJZUtatIrAGXRCM56Np08LbjXC7WVSqhdx3ZWeulFK8CBoP3pVZxnivdyhdFGpnpzOwqKtvA8mlHJlOJ4PLMH31+u/1qk+MwOqqfKR+tWr41rxIUDw9etVgQyQRrWiKMkmW/F+PqMOqhEOUIcxLAgtEjblNecXmzMxGgLE+5rVcYQHDtB1CrMxEh9IPPQ1lQKpGKQrlezgFOFKKkRJ/U1VIm5DAKcBUww55MvuB+MU7+VbkJ8iD+Bo0I5Igip8OujHTQD8eVNayw3Vh6GpsJPegkacjBj865CydoSYdm1AkeQ50OV30q0wmKyrEDaOp8/rQN+CxjQcqahYttk3CCA6EmBnADQSASViYYfn5UaljPfugAsJecuxAUwd2gcxqYoLhhhgDcCDMM0s65l56r06jeimZfjO6nOsuQc2pBUwcx1n86CWSj0Ow5/xUB0XIBqZUjJziOnOhb9wywhYVogEEATynfUb/APFG4Nv8VIBBCHedT8MyJUz+Yig8VYM5jlBJ2i4MxG5Bca+/pTaYEsAObpUjXFOpUgnwP61ARSims7qEKVGx9/8AxTrSid9Pf8KFAqTDEBgTtqD5HSus5xwEsoIOusSPTx9KBZasL7gkkHQLAHMchPXnQSjQ1zydGNIgilT8tdodSlGfSk1JN6T715x6Z1FkxUxw9R2d6JN00UkLJu8DEwxO1H3rBCjNrO1C4ZxmOYxpRD3sygTtTJISTdjsLbjU1Z4a0HYLzNVtr5SZiKP4JcOctuQNqpFW0iHLJqLaLzH8MR8Gyrq9pp/tcfqGPrUf8PLRu4q2LjMxtBrihmJ7oGVYnYBmXbaKIwuLILAjLnUq08xMx9BU38Or5XGNaIUqbbsjR3lOdCyhvumCY8RQ5Y0myf03I5OmetYNVJIbwrKcWtyGVYEyJIBMHQ71f3CY0qqxNkms0MM1zyqK7stwFEaT3yeWw25RtQHHuHhbtxSchKZlMEksCBk05Gd+laTguKW0XZ50GkKWPWFXUmhO0t1HvWn12zsCpViigMRB20HPwp032JSUeh532gsNZRbTTmLEttpEEL0+Yab6a1nwK0Pa/Fl7gzGW1dvNogegAqhArXBYyZW/gUVPaXut6fnUcURaHdb0/OnSJSeCOKKwNlWFzMJy2yy9GDIJ9ia4mHBts86q6LHKHW4Sf/wPerXsxgrjteyIzD4FxdATqQAB5yRpQlhHRyylTNyJHlTjcfmx9TP41qsH2RxLD/JYeZUfiaruJcMNslWEEU66vCZJzafuTopM56H0FPtAMwBgA6TTWWpcKFDDMuYcxJH1Fclks6q0BkRU9m0xGgmmONT5n8aKwmIZFIHOmileRm3WAUgjpSznaTFSPrTFWi0MhC1pM/Sfzp/8qSQFkkmAIMk+AAmTUqroND58t/GtPg+BK9lbjXFRiCFUtlZsu2XYKZ85kbUrpCtsyPwNOXhvH40xU1qzIIiQRpr47TzoRlAaNxG+2utFo5OyF0IMHwB/6gCPoajUb1bJhkdQzXVDxEGZ7ohR7ACq1V3rkh07RDFKpMlKuyG0ZpRSYa09ErrJWHob+w23vWhvdksSEW4q5gwmAdfrVAq1692g4w9rAW3QKDlUa9aKiJKTTVHk2Iw7o2V1Kt4GPypi1PjMU91y7mWPt6VEFoUP4ySr8po7gj5bgkwDQ9i3oaciQZqsFTTM/LUouPyazFHMDm0A2NAdksYLePtNPdL5P/sBT/uHtQIvuwyzpQyqQZGhBkedWnFSVIxfTwfFds+g2E1Fi3Rbfyy2/wDxWL7M9tgbTnFED4YlnWSWWQMzKNZBKgxuWGgraOVdAyMCpGkVglBxeTepWsFNicWEEsjLpyGYe6zWWTEBy7GSS2addN9D6Aexq9467qCA0A1muK3fh4YEMCXzDKCZUyVJYciVE+1WhHBl5JNujJ4u8XdmPMz6ch7RTAK4BTwK0JEmzoFWHC8BcvEpbRnYxoOW+pJ0A6mhLFlnYKoLMTAA1JNewdmcJZwuHWGEuod2MasQNAfAbAedCcuqxsMYdnl0jK4rsn8Cyq3HEuc7kfKGS3cIQH1351sOx2Lsfy1tUZe7bOYAiQykZ565jP8AcPGhrGOOIDyFZMxXKRM/4d0z7gCqHsdg8nxlHyqt9BpEibEED+01nknJNSKxlGL7R1o2d7tBYCsVdDlEmDOhIH4kV532m4ot15XYCJ8aDXCNbbE2gZORMvUPeslZ6wwqluXCa08PFGLtGXm5Z8mHoic611AJ1qTFqA7gCAGYDyBNF8Wwq275RdlCepyKSfMmT61esnRbSK1xqfM1PhXCjUTTHTvHzP41PZQRTRgyrVxF8dcpGXU0Mgoh7VR5aMoseKSWAlrK5UOY/wCru6DvNsZ10A5Dfpr6LhSVRGKj4CpbXMAGOXuMhYZoEMCDpEtuIrz22hKqIMR4HmTWx4NxVVtotzRkVlC5WKsCxK52jQAxtuG15ioc0G1gRSSeTOcbtD+YvHNpnYgxA7xJI56CarcZh4aI2kexOtWLsHuEvKhnJZgCQMzSWCmOXLShMTrHl4zVlDAFLJX/AA6elupwlSpao9KGcgHJSo74FKu6g7mMQU5hUosmo3FYtGxStjVWvWe0GCDcOtnOJCKwDRB02ryhBrXsd/Ci7w62t3Kqm2veaIHd0MnagLOWUeOOZMwB5VwCrHiXDvgkD4lt5+42ePPSg0tliFUEsTAABJJ8ABqTQotGVonsjQ+lHphQRNabs12OI7+KOUEaW1Izf3tsvkJ8xVljOy7KSbLoy8lbusOkjQ/SqQlHTM/MpeDGYHCOxbIhI8Y096jsYG495LMAM7BJJ0UucqlomBmIHrWxt8JvqhEKzHQKrhfqRr5VSYXEixiUN/CsVhkdHZSWDaEqSqgEMJ30I3FNKeKROMc2ybG4K9g0KYiyVM5i4yN8T/Et5QrDTKqoTB5usjeqO1x3EWLk2bjKsAlZVg33i0iC0yM2h0q+7ZFWZfhNea3lBCXbgufDJEwveaBHLMareEcPctItW2PP4g7gHr6c6SPG5xtjucYsOudpL162bjondyzGZZzEgEAzpII3qnxuOe4RmgAbAbefU/pWoxeFuGw6lMGmRc2kZlVGDEWxOjEgiI1DEc6pcDhTedEJtBXJVWkLDRMMN5gGAd6MUkRk7eEVSijcBw+5dbKikkKWPRRufKjeFYQtiERLIuSxUBmORyJ1zqIA0nmIHOtNjOxLh1Z2DqT3xDSin7pkbctPSn7RTqxesmrrBSdl+HF79ko5Vhc7/dBAQITMnm0MsEcxXptvsrbE5WeDJIzkrLGSQp0XXXQClgOE4dQDYABBzc8+aIzMTqW13kzRSXbyEyPiLGwgOPcwfp5Vk5ORydxdGnj4oxj7lf3Q3AcGWyhCkk5iw2GuVhrA2gmh8Hw5bbXWCwSXI6hyrGOgIj0qO12mzFlFi8xUFu6F2GhAkiTrsKDxPatUz5sPeUBSZbIsyeQLSfHbnSqPI20xJenS64SHW+DZMRcvaEMmVYnQKtvQjYajSs7iOyD5boEBQquoBliyWX0M6d52/GrC728sEQLVzefseA69K43byzBHwXkrlmV8Iq8VzJaIey9lKeylw3u8MwLqSo3KNnLddGXLprrTO2vDmS+hP2k5H7rEbHpFXi9vbIYN8B/dfvTVB2q48uLKMtt0KZtyDIYg8vKr8fquaclgEuijh5M847x8z+NSI8Ux0bMdDueR8aQtt91vY1tGhJNZJHu9KYjajzpfDf7rexpC033W9jSsduNFng0LwswYMcufP3o2xaCXUDBjmIGUwRqBoRqNqF4XiFEAqA45kQYLLHpRl3Eo91SrA99QOR1eJ16aUrfgzPZWPiFEjINz9pp08aaxDHQRpy86HuN3m8z+NWHA7Za/bA1JZf8AcKe0lYW6GNhssTzUMPJtRU1q0Kuu0PCGt5CAxC21QmNBlXc+xoC7bCHKRqAJ31JXNty3A9KEJKcbRDk5ejpkPwRSpfGHgPr+tdrurE/6EYA3aiL1GKcBXnNtntqKRJbbWve+C8OF3A2EvKpHwkJVgTHdESp/OvPv4c9mxdcYh4KIx7hE94Duz4HWR/T1Br2dUBQA+HjFR5Z1SQygnk8n492PwNtiTj1s5pbIQrAD/SoMx607CYvhmAyqGuYi+w77hcrKDsIYjID90SYieVXXars5auNmDISAfneCOgIM15tj+HfBKxGRj3WI58wf9QP5Gnguy2C+p6tax1jEozWMyumrIwKvH3h4jyqsuONzMn39TWTt8XbC3Eugp3WUsFKsWSQHGnIifWtFxK/8O86qZQwyf0OAy/Qx6Uzj1lSEhJyjbCbF9NgXQ/eVjPtzpPhM2rMjg69+ZkbHWRPWaDtYqdYiiPjnxpQtIExfZ6y7ZodCd8jKF84gj1p3/oqIjKt+4Awhh3TI66U97p8TUJcnSTVIya8kZpfBmeK8LYwFfPExm7sSZMATzoPD2GtusXCGIIzKSGVWUqyzuDDEesiRBrRsutWvBLaKHuuiHu5UdgGYOpDHKNwoUyToBpTtqrZJN6WCo7K4lcJd+LctlUbKA+USgYNqJGZlIO48B416vguK2rqghlYeIIkV5XxTErddAVYjIqjMMqQqzn13HMcojWKgu44i4PhKiue6rLIXQR3R+s9NIpeTijPPkMPqJceNo9F7V8QXD2s9sZrrHKixrm07xjkJA6kgc6yNztxiVt5LyrnDqrvoIXNDjzjQxPOo+z+OfE4pLd1jcVA8N8pUplKspB1OZAZIjQdaZxrgKJeuO1x7hId4bLGYhtWgamWnltU4ccV7Xlj8nI2u2l8A1rtBazN8KyltlBKlTqRroNNZAJ9KucTxEYhVzALKmSOUjy1rOYfBoiu2UBsuUHmM4y6TtoTtRFtWRCSCAULCdm3AI6SCPTrWjr5MLmtR0w5+FIq5viMRy03j1qrv4vI7KVVsrEbsVPsdvKrJL7NYRsoypmZ+is8Aif6D9Kzt18xLczqfPnVot+WTaTeiysYrM3+WgnSCxVdRHM0zFYmGIVcoBgasdjpAmKrrbGd6lxfzt/UfxqsWCsjGvN94+5qIufE00qTUow5yzrueVGzTBpEWalNT4izlVTyP+7mI6aULStlouyb4hXKRpp+c01bxGo09/wBa4ROQHY/qaV63DQK56sm2k6Oo+tWnBeILZurcInLqOeogjmPCqVjFOV6F4pitW7PQLvbq4RoqAdVY/wDfVRxTF5nZ7hIdlUqAi5T3QBrnkCAPGs492Vqx4y5zJp9hf9q6THLzPptQjxwg/YqJzjKf9nZ0Yk9PYUqrlbrXar2IeijIqaJZhpNCrvpRC2zmUsO7InynWvLTPoHV5PeexvDRYwyAiHfvvO8tqFP9KwvpV7cWajsnQVMKzN27KJYKXiGHBnSshxPCrJR0lDvuSp+9H4/8Ct9iUmqTimGZgPDYagU8J0JKJ5n2rVkX4bESpDLoASjDcQNQYBozA8Q+JZsknvJbCH+wkD6VYdrOFl7TkSwt7DOWlRM5dSJkjTfXzrJcKJW36mPc1Vyt2TiqjRrbF2jEes1hsTJEb/vWraxilPiP3rSgkWbMPb61GRr4VDadnMKpY+AE/hVvhODO0Z4QeG7H8hR7JbJOLeijapLzJcVLVti7IAzoJVTmbM+dzAVQsKQJJI6VJ2rP8uFS2sHIXdjqxUEAifDUaCN+lB4XtSxGfI6G5czZlChXtyc6h4DZg0CJIAJ2O7dm6om4Vdk3F8e9xwLyZmUBAFDHIu5BJUSeRJOo9ZiQBu9rpMaaDSPmO5nw00onHJdOR3eEcwrZpBkA7QNY1kxz8KiVANB3jtJ5+x86rGksGScm3ktuxmFRLxIGuRteZ1Wp8VZN646ggGIEmBvr9AT6UJw6+1ts4ABXpyjUH0qov9oDiG7qG2VYNoROvWPED60qi3K0M5fx0/DyW+BRUtXjdQOquEfQnQBicsEc1GvhVY3F7VxEFwBSvegKSMqOSloDbKQzeqrJqzwGOZ1KPqHlToNW0KEkdRH9xrHYqzkdl8DHpyPtFPFZdiRalFUGYvib3SxYgSACqyFiZ2nrQRrlvY+X5iuE1a6BWRynWrDiOIzsYRVyiDkU6hSZduviarQ8GfzorFY64GPeIGUoIgdwnVfLSu7BrJDZ5kawf1qzwjgoF8Z18ZgH6/7aqsLeyEMDzFWeDBdgZiNRJ0iddOmY+1HsEZjbWc9wHvMcugJOUwduelALYJR3HyrHI6ljEA9Jq0sY7KXYE50WOXzFhm5dDQVziYzsQBlCQgyj5hlymNvmUGja8lIuXgHsWi0EbD/mKkxcDUHWm4nFgKMh1eWfSIJiQOk5veq5rk1zmkqGjxSlLs9Dy9dg1AWrScCw6MMzBWBnSO8CJM/SpdikodUVb2yLQeRlLlOcyADt4a0Tjb6uyZdIRFJzLqQoE9NfEn0pcU0txy+MxHqi8vT61U2z4VzkxFDFhdy8JOo9xXKGNp/umlXdpfAesfkz9l4NXHxO6J2qiU0YmKMBeVY4zo9HkhZ7/wBmOJC/hrbg65Qrf1Lof19augdK8X7E9o/5ZwlwxacgE/cbYN5cj6eFew2b4ZQQZB1FQmqY0Haofc2oDF2ZBo8tUOIGhPIdQAPOlTHaM9i8KWQ29AGHdMfK4+XfrofOsDibSIcoTKZMjqCZXpBkV6DxG4jlQjqz8gGWfTxprcFtM/xbiBnMEqdUDRDNHMmB00qnatket6MHgeD3b2ttIB0zN3U9+fpNazhnZdEg3GLt4bIPTc+p9K0iW55USmHpXNjKALhsKAAFUAeAAA9hR9uyBUbOFoa5ijS5ZzaR5/8AxOxJXEx9lrKr/bKzHXMtRdlsY5whsLkzXLwVVZWdwrLLMsEBRIA23aave2PCf5q2sGHTY+KkyV/H3oHs/dbBnuxAWCT9pjGsTP751eK9v4MnJJJ/n/C67QMtxbSI2fJclgOUAjkB5aUzs9w/NiFLKQoncEAkeZoC5xIuTmVWJJILT47ZQYA6VHYxjZ5thUI+0ARVVF9aRkc4902rLrtDhlW+4UaFQffesWyhLpXKYOoI005A6elW/FeOPbABfO5IJmCMo5Hz296qeJ4hnOXMdvi2mGmZdypA5gBhHihpoXFKxZxU22lsNshpgCDmmToBAkanyqHj2FBdXzKA4112I8tdiPahbVzMobxP151Pi0zWj4rr6VZ7sywbi+oELSLtdV+iq/8A3KKZfVdwDH760Na3oy6n+HP73orRWWJICYqORPqP0qVzzgnU8x+k0M4oi4srpIMnWSR/0gae9CylaIFbcRv50R8ZcsRqZnoSInr3aEGhI50mtN4Hz2Hua6x6VkxxB18Sd/H8qEdqlc6QWX3n/bNQHL94nyH6kVzkVgkjr7D1qMmk7TETHXemkUjZojhCmiLeKKhgD82/1/U0IwptCwtJ7Crl8lAs6Az6xH4VJgn1oRQYp1u5Brk82BxTjSL3OaVVP88aVV9REPR+xQJhHMafNMSVAOXfUnlTxhCNS6DpmBPsKLw2DV0JUCUJzMS0MD8sgQFiCOczSweFzXQjZADrKlDpEiNSK89I9Js4zLkjNJmJA0iJ51qOz3bJ8MURwz2eeveTqviOnt4VnMWjpopaFOjBcsQdO8NN5I8qs+z6q4uPdDFwxb4mQXNSuuY5WM89fEUXnDEwsnstvi1o2fjhwbYTPmGvdj8eVeV8W7TXMe4toGCM+VLYOhEwC2veJ61BbxuW1iMIoZVdMyrvBW4c2WXaCREifszGpJX8ObSHGrocyI7CTse6sx5Maml1tjN9sHoPZns4uGUEw17LlL6Qq6SiaaDTU8/StBbQc6EfER7UO2JNI7bthVRVIuvjItC4jiE6Cqw3JppcCiogciZ3J3oPGY5UHXwobHcRCiBvVDfxBJzNqeQq0Y2ZpzrQVjOIuwMmJ2UefM1XrcqFSWJnc/qKtHGHgaPmgAkQNoGxPgPDnV4qjDOVs5hcGzwBpIJHWDBonDWsoII1n8KkTiypkyoISdz94kkgAdfGj8filL5kAysoYCBpMzvPjQbd0BRi1fkwvEUJuuSdcxgbmOX5Ufwa0zsLZUiGzI5EBW0BWTybu+uXkTQ/G8c4usuYwIiDESqz8seFVZvsTM6+PP3OtWq0BJlviLBtuUKlQ3fVSIK7hl9D+9aLwbT3TsRFTXcYuKsBnYDEWuZiWXSdesCgsO0EH1oRbapkOdJO0BYhMrxRVwTamP3NS4/DTDdaMXCzZgdB6mrIhLlTUX9zNFNJpnxCeY9gfxqxFghWG7KwUxr8066eEVXpamTBIAk6gaTHOedTZsg7uyF3bxPpp9BUeQkE0betjukZQCJ1kk+hFWlmxGFfwbMw+VSQCg2BJjQ+FAp2pGa050jdHhXG2qE0t0WSsKtYsL9mn3nkAkgE8gNR15ddp28qANGWsI7mERmOp0GgA3JOwHU0ezaofqk7I17zBVEk+J08ztAHj0qb4aRALDwcgZJ8vmC/6vpUNtcrd4TB1E7xuJHIxEjxorGZdGUyr6wSARuCCN5Go08/ChQ95oDQk7nmN/WoC1SI2vqPwNQMaWTKJZO5qVMpUllKDeAOuS7CSwUEkECBr8kzr503BYxmvoubKBm+0HAkEzKgLNO7PW7mW6bWjQN1zaCdB1pmCwjJdV7xUTJIzLmiDrlXlpUqeAtq2CcTVpYkCM28a84OY6memlWvZdUyOWVmae7lZQflkgLOaeoB+lVmNRGdimZpYx3TPqSZ+lX/AGUQBnCl0YgfcIIhjrmHd2bUeNdWQSl7aOcSW4j/ABf5ZVyAEuz3myrJgQ5UkwfDUEdal4P2gRcQl1ktIpYqzKqoxVhBJEMdJk94SRND9rLQjN8YvDwFzFonm0k6wOlZq02VgSoaNYOx6GuaOWVZ7m+IDAMCCCJBBkEciD4UP/MCvLcB2gvW+6p7gX5DJXQcgfl8hXovZqw+Kw6XwyhiWBXUQVYjfXofWlaS2dl6DDd8KExd4gR9at7HCnB7wEeY1p7cHUnM5nwUfL6nc/SgpJCOMmjMW8Kz94zl8fGoMRZrWYuyI2qhxiVWMrITjRTtbpIKmuCoxzqyMskd5UZh705OgihF2p+DU5hRrBLKZTcfEXm6gH6VXA1Z9pP87+xfzqqmni8FksBWEALKGMAnUjetPxnBKrWzbcukCSdxWb4SAbqg7T9YMVf4a/ca6EPeUEiNNuVd5slyrDVZ8FoiK+RcoEDXrRLYQKoH2Swg9dKiJFoknXTSmYbizOfhBASdRM/MBIAHjoTTOS2tHmrim8NZI8JgQpncuxY/Z3DkCemtE4XhaC+zQdVUQYjugaR6L51VYXid5rnwmLDLt8NQuaQQCWMQNZ60Bdx134zq11yJYQGjYHU5SAYiduVBtNmpcXJWZFxc4faC2mYbKdWPJs/j6ew86n4gLKWIRljI06gwWIjaQNtt6yfEsLlW23eggySG1OY7kga/pR/G7MpbKq7/AOEhLBYRBr3S+s+/6V15VFVw3lysy71FFTEUwihRsTI8tW3FbICW25lFncgkg+k6baHbTnVUTVpxj5LJy/8AtrrI1Gu433/L0Gh7yittPBBGhB02jpIOhExSVDIEHfTz5b1HbuZSDAPQiQRzBHhUj3xByIFkQSWLGOYUtsD79aRsogdXg+IqMvTiKYEmkdlVQ3OaVO+HSpaY1o0/ZfgzMl05QAANS08jyFQXeHizdQEAEzmAVQoAB8DJPWlSqlKiLk7K7HW4ZiRJnQZm5+P/AJq47JZHS6rqgCkHNEsJEaSDtlmuUqVjeCPiXE7WfKbRu5IWGYqnSEUAaE7kUEezF4q11lW2gOstmidQAFnSu0qVhutFfcw9tRpdztB7oVgJ/qaPwre/wj4h/m4c/wDyp9FYdPsfWlSoTWB4vJ6WYqJ9qVKsxVldiV5VQY214mu0qvAycxVtbB6/SoSBB0H7mlSq6McjgYx+mn4VEcatsaglgCYHpuT/AM0qVMTWyi4ji/itnyxpETO1C1ylTIsPtOQQw0IMjzFXBxzMRdXRhv6UqVEnyB+Mx9+4AvdHdzef6UDw/GmRlMMpzA/n5jelSrvBOrVs1N60jhcWGyZptuoDaPoWykEafaHmRWcxFoDEXeQ1iJ2CmOfPrNKlQ4vP7G5NP8IBx93MLepOhGu2h5eA9tqL401oqhFwlhbUFcrHv85ZiIERtNKlVArx+zPMaYxpUqVmhDDRGLxpZVWWhVCxPd05gClSpWOkCZ6a93SIpUqmx0hy2jlzcqatvSa7SrqOUnn8kmUUqVKuGP/Z"
        },
        {
            title: "Использование AI в медицине",
            description: "Как искусственный интеллект трансформирует медицинскую индустрию.",
            imageUrl: "https://webiomed.ai/media/blog_photo/obzor-rossiiskikh-sistem-iskusstvennogo-intellekta-dlia-zdravookhraneniia_nQ6WJUD.jpg"
        },
        {
            title: "Этические аспекты искусственного интеллекта",
            description: "Обсуждение этических вопросов, связанных с AI.",
            imageUrl: "https://avatars.dzeninfra.ru/get-zen_doc/271828/pub_65259f54ba9cbf61341e0dbb_65259fbb8365541c39986742/scale_1200"
        }
    ],
    blockchain: [
        {
            title: "Как блокчейн изменит финансовую индустрию",
            description: "Дискуссия о ближайшем будущем",
            imageUrl: "https://www.tadviser.ru/images/4/4f/Blockchain-tuir.jpg"
        },
        {
            title: "Блокчейн в правительственных системах",
            description: "Цифровой рубль уже близок",
            imageUrl: "https://img.gazeta.ru/files3/531/8042531/shutterstock_284887238-pic4_zoom-1500x1500-570.jpg"
        },
        {
            title: "Блокчейн и криптовалюты: будущее денег",
            description: "Как бум майнинга перевернул наш мир",
            imageUrl: "https://cdto.wiki/images/7/76/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA_%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0_2020-08-21_%D0%B2_13.10.57.png"
        }
    ],
    webDev: [
        {
            title: "Новые тренды в веб-разработке",
            description: "Изучаем новинки 2023 года",
            imageUrl: "https://cdn.sanity.io/images/35hw1btn/storage/5c2ba33be6cf54c00a86c20c659d269573f62aae-3840x1230.jpg"
        },
        {
            title: "Разработка кросс-платформенных приложений",
            description: "Почему важно реализовывать приложения для разных ОС?",
            imageUrl: "https://surf.ru/wp-content/uploads/2022/11/Frame-473826267.png"
        },
        {
            title: "Безопасность веб-приложений",
            description: "Разбираем кейсы больших компаний",
            imageUrl: "https://river-it.com/upload/iblock/7e7/g90ub59d0h1ulb2kr6eg1lqfetu5hkng.png"
        }
    ],
    cyberSecurity: [
        {
            title: "Текущие угрозы в области кибербезопасности",
            description: "Разбираемся с чем придется столкнуться в ближайшем будущем",
            imageUrl: "https://freevpnplanet.com/xx/blog/assets/uploads/2021/05/rvpn-3-20220325_191921_008861.webp"
        },
        {
            title: "Защита персональных данных в интернете",
            description: "Следим за исполнением ФЗ-152",
            imageUrl: "https://media.kasperskydaily.com/wp-content/uploads/sites/90/2015/12/06043506/privacy-10x10-FB.jpg"
        },
        {
            title: "Кибербезопасность для бизнеса: лучшие практики",
            description: "Что делают топовые компании для защиты своих данных?",
            imageUrl: "https://www.kaspersky.ru/content/ru-ru/images/repository/isc/2022/small-business-cyber-security-img-1.jpg"
        }
    ],
    edTech: [
        {
            title: "Эволюция дистанционного обучения",
            description: "Как пандемия COVID-19 изменило образование до неузнаваемости",
            imageUrl: "https://static.tildacdn.com/tild3865-6437-4462-b365-363263363235/01.png"
        },
        {
            title: "Интерактивные технологии в образовании",
            description: "Что изменится с применением интерактивных технологий во взаимодействии преподавателей и обучающихся?",
            imageUrl: "https://www.polymedia.ru/images/spravochnik/9512.jpg"
        },
        {
            title: "Виртуальная и дополненная реальность в учебном процессе",
            description: "Что могут привнести новые шлемы виртуальной реальности в образовательный процесс?",
            imageUrl: "https://e-asveta.adu.by/images/content/images/material/1-41.jpg"
        }
    ]
};

export default articlesData;
