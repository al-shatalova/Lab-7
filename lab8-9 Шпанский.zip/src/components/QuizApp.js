import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


const StartScreen = ({ onStart }) => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');

    const handleStart = () => {
        onStart(`${firstName} ${lastName}`);
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-3">Проверьте свои знания!</h2>
            <h4 className="mb-3">Введите свое имя и фамилию:</h4>
            <div className="mb-3">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Имя"
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                />
            </div>
            <div className="mb-3">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Фамилия"
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                />
            </div>
            <button className="btn btn-primary" onClick={handleStart}>Начать</button>
        </div>
    );
};
const Quiz = ({ userName, onQuizEnd }) => {
    const questions = [
        {
            text: "Какая правильная команда для создания нового проекта React?",
            options: ["npm create-react-app", "npx create-react-app myReactApp", "npm create-react-app myReactApp", "npx create-react-app"],
            answer: 1
        },
        {
            text: "На что myReactApp ссылается следующая команда? npx create-react-app myReactApp",
            options: ["Каталог для создания нового приложения в", "Имя, которое должно использоваться для нового приложения", "Ссылка на существующее приложение", "Тип приложения для создания"],
            answer: 0
        },
        {
            text: "Какая команда используется для запуска локального сервера разработки React?",
            options: ["npm build", "npm run dev", "npm serve", "npm start"],
            answer: 3
        }
    ];

    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [score, setScore] = useState(0);

    const handleOptionSelect = (index) => {
        setSelectedOption(index);
    };

    const handleSubmit = () => {
        if (selectedOption === questions[currentQuestionIndex].answer) {
            setScore(prevScore => prevScore + 1);
        }

        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prevIndex => prevIndex + 1);
            setSelectedOption(null);
        } else {
            setTimeout(() => onQuizEnd(score + (selectedOption === questions[currentQuestionIndex].answer ? 1 : 0)), 0);
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4">Квиз для {userName}</h2>
            <div>
                <p className="mb-3">{questions[currentQuestionIndex].text}</p>
                <div>
                    {questions[currentQuestionIndex].options.map((option, index) => (
                        <button
                            key={index}
                            className={`btn ${selectedOption === index ? 'btn-primary' : 'btn-outline-primary'} mb-2`}
                            onClick={() => handleOptionSelect(index)}
                            style={{ display: 'block', width: '100%' }}
                        >
                            {option}
                        </button>
                    ))}
                </div>
                <button className="btn btn-success mt-3" onClick={handleSubmit}>Отправить</button>
            </div>
        </div>
    );
};

const QuizApp = () => {
    const [userName, setUserName] = useState('');
    const [quizStarted, setQuizStarted] = useState(false);

    const startQuiz = (fullName) => {
        setUserName(fullName);
        setQuizStarted(true);
    };

    const handleQuizEnd = (score) => {
        alert(`Квиз завершен. Ваш счет: ${score}`);
        setQuizStarted(false);
    };

    return (
        <div>
            {!quizStarted ? (
                <StartScreen onStart={startQuiz} />
            ) : (
                <Quiz userName={userName} onQuizEnd={handleQuizEnd} />
            )}
        </div>
    );
};

export default QuizApp;
