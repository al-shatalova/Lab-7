import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <Link to="/" className="navbar-brand">org.fa.ru (ну типа) + СМИ для программистов (8 лаба все-таки) + Квиз (9 лаба все-таки)</Link>
            <div className="collapse navbar-collapse">
                <ul className="navbar-nav mr-auto">
                    <li className="nav-item">
                        <Link to="/students" className="nav-link">Список группы</Link>
                    </li>
                    <li className="nav-item">
                    <Link to="/info" className="nav-link">Информация</Link>
                    </li>
                    <li className="nav-item">
                    <Link to="/news" className="nav-link">Новости для программистов</Link>
                    </li>
                    <li className="nav-item">
                        <Link to="/quiz" className="nav-link">Квиз</Link>
                    </li>
                </ul>
            </div>
        </nav>
    );
}

export default Header;
