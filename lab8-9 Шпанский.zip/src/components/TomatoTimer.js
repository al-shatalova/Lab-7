import React, { useState, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const TomatoTimer = () => {
    const [time, setTime] = useState(1500);
    const intervalRef = useRef(null);

    const adjustTime = (minutes) => {
        setTime((prevTime) => Math.max(prevTime + minutes * 60, 0));
    };

    const startTimer = () => {
        if (intervalRef.current !== null) return;

        intervalRef.current = setInterval(() => {
            setTime((prevTime) => {
                if (prevTime <= 0) {
                    clearInterval(intervalRef.current);
                    intervalRef.current = null;
                    alert('Время вышло!');
                    return 1500;
                }
                return prevTime - 1;
            });
        }, 1000);
    };

    const stopTimer = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    };

    const resetTimer = () => {
        stopTimer();
        setTime(1500);
    };

    const formatTime = () => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    return (
        <div className="text-center my-3">
            <h2>Таймер</h2>
            <div className="timer-display mb-3">
                Оставшееся время: {formatTime()}
            </div>
            <div className="button-group">
                <button className="btn btn-success mx-1" onClick={startTimer}>Старт</button>
                <button className="btn btn-danger mx-1" onClick={stopTimer}>Стоп</button>
                <button className="btn btn-info mx-1" onClick={() => adjustTime(5)}>+5 мин</button>
                <button className="btn btn-warning mx-1" onClick={() => adjustTime(-5)}>-5 мин</button>
                <button className="btn btn-secondary mx-1" onClick={resetTimer}>Сбросить</button>
            </div>
        </div>
    );
};

export default TomatoTimer;
