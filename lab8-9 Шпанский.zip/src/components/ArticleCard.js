import React from 'react';
import './ArticleCard.css';


const ArticleCard = ({ title, description, imageUrl }) => (
    <div className="article-card">
        <img src={imageUrl} alt={title} />
        <h3>{title}</h3>
        <p>{description}</p>
    </div>
);

export default ArticleCard;
