import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { studentsData } from './studentsData';

const StudentsPage = () => {
    const [students, setStudents] = useState(studentsData);

    const [filter, setFilter] = useState('');
    const [selectedStudents, setSelectedStudents] = useState([]);
    const [newStudentName, setNewStudentName] = useState('');
    const [newStudentPoints, setNewStudentPoints] = useState('');
    const [newStudentAbsences, setNewStudentAbsences] = useState('');

    const toggleSelect = (studentId) => {
        if (selectedStudents.includes(studentId)) {
            setSelectedStudents(selectedStudents.filter(id => id !== studentId));
        } else {
            setSelectedStudents([...selectedStudents, studentId]);
        }
    };

    const deleteStudent = (id) => {
        const updatedStudents = students.filter((student) => student.id !== id);
        setStudents(updatedStudents);
        setSelectedStudents(selectedStudents.filter(studentId => studentId !== id));
    };

    const addStudent = () => {

        if (newStudentName.trim() === '' || isNaN(newStudentPoints) || isNaN(newStudentAbsences)) {
            alert('Введите корректную информацию о студенте.');
            return;
        }


        const newStudent = {
            id: students.length + 1,
            fullName: newStudentName.trim(),
            points: parseInt(newStudentPoints, 10),
            absences: parseInt(newStudentAbsences, 10),
        };


        setStudents([...students, newStudent]);


        setNewStudentName('');
        setNewStudentPoints('');
        setNewStudentAbsences('');
    };

    const filteredStudents = students.filter(
        (student) => student.fullName.toLowerCase().includes(filter.toLowerCase())
    );

    const deleteSelectedStudents = () => {
        const updatedStudents = students.filter((student) => !selectedStudents.includes(student.id));
        setStudents(updatedStudents);
        setSelectedStudents([]);
    };

    useEffect(() => {

        const script = document.createElement('script');
        script.src = 'https://www.kryogenix.org/code/browser/sorttable/sorttable.js';
        script.async = true;
        document.head.appendChild(script);


        return () => {
            document.head.removeChild(script);
        };
    }, []);
    return (
        <div>
            <Helmet>

                <script src="https://www.kryogenix.org/code/browser/sorttable/sorttable.js"></script>
            </Helmet>

            <h1>Страница студентов</h1>


            <form className="mb-4">
                <div className="mb-3">
                    <label className="form-label">
                        Имя и Фамилия:
                        <input type="text" className="form-control" value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} />
                    </label>
                </div>
                <div className="mb-3">
                    <label className="form-label">
                        Баллы:
                        <input type="text" className="form-control" value={newStudentPoints} onChange={(e) => setNewStudentPoints(e.target.value)} />
                    </label>
                </div>
                <div className="mb-3">
                    <label className="form-label">
                        Пропуски:
                        <input type="text" className="form-control" value={newStudentAbsences} onChange={(e) => setNewStudentAbsences(e.target.value)} />
                    </label>
                </div>
                <button type="button" className="btn btn-primary" onClick={addStudent}>
                    Добавить студента
                </button>
            </form>


            <input
                type="text"
                placeholder="Фильтр по имени или фамилии"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="form-control mb-2"
            />
            <button
                className="btn btn-danger btn-sm mb-3"
                onClick={deleteSelectedStudents}
                disabled={selectedStudents.length === 0}
            >
                Удалить выделенных студентов
            </button>
            <table className="table sortable">
                <thead>
                <tr>
                    <th>Выбор</th>
                    <th>ID</th>
                    <th>Имя и Фамилия</th>
                    <th>Баллы</th>
                    <th>Пропуски</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                {filteredStudents.map((student) => (
                    <tr key={student.id} className={selectedStudents.includes(student.id) ? 'table-info' : ''}>
                        <td>
                            <input
                                type="checkbox"
                                checked={selectedStudents.includes(student.id)}
                                onChange={() => toggleSelect(student.id)}
                            />
                        </td>
                        <td>{student.id}</td>
                        <td>
                            <Link to={`/students/${student.id}`}>
                                {student.fullName}
                            </Link>
                        </td>
                        <td>{student.points}</td>
                        <td>{student.absences}</td>
                        <td>
                            <button
                                className="btn btn-danger btn-sm"
                                onClick={() => deleteStudent(student.id)}
                            >
                                Удалить
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
};

export default StudentsPage;
