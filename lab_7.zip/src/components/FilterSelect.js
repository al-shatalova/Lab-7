import React from 'react';

const FilterSelect = ({ filter, handleFilterChange }) => {
    return (
        <div className="mb-3">
            <select
                className="form-select"
                id="filterSelect"
                value={filter}
                onChange={handleFilterChange}>
                <option value="all">Все студенты</option>
                <option value="selected">Выделенные студенты</option>
                <option value="unselected">Невыделенные студенты</option>
            </select>
        </div>
    );
};

export default FilterSelect;
