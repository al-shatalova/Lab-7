import React from 'react';
import '../App.css';

const StudentsTable = ({
                           filteredStudents,
                           handleStatusChange,
                           toggleSelection,
                           removeStudent,
                           handlePointsChange,
                           sortByPoints
                       }) => {
    return (
        <table className="table table-striped table-hover table-bordered">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Студент</th>
                <th scope="col">06.12 (1семинар)</th>
                <th scope="col">06.12 (2семинар)</th>
                <th scope="col">20.12 (1семинар)</th>
                <th scope="col">20.12 (2семинар)</th>
                <th scope="col">Выделение</th>
                <th scope="col" onClick={sortByPoints}>Баллы</th>
                <th scope="col">Удаление</th>
            </tr>
            </thead>
            <tbody>
            {filteredStudents.map((student) => (
                <tr key={student.id}>
                    <td>{student.id}</td>
                    <td>{student.name}</td>
                    <td>
                        <select
                            className="form-select"
                            value={student['06.12 (1семинар)']}
                            onChange={(e) => handleStatusChange(student.id, '06.12 (1семинар)', e.target.value)}
                        >
                            <option value="Нет">Отсутствовал</option>
                            <option value="Оп">Опоздал</option>
                            <option value="Был">Присутствовал</option>
                        </select>
                    </td>
                    <td>
                        <select
                            className="form-select"
                            value={student['06.12 (1семинар)']}
                            onChange={(e) => handleStatusChange(student.id, '06.12 (1семинар)', e.target.value)}
                        >
                            <option value="Нет">Отсутствовал</option>
                            <option value="Оп">Опоздал</option>
                            <option value="Был">Присутствовал</option>
                        </select>
                    </td>
                    <td>
                        <select
                            className="form-select"
                            value={student['20.12 (1семинар)']}
                            onChange={(e) => handleStatusChange(student.id, '20.12 (1семинар)', e.target.value)}
                        >
                            <option value="Нет">Отсутствовал</option>
                            <option value="Оп">Опоздал</option>
                            <option value="Был">Присутствовал</option>
                        </select>
                    </td>
                    <td>
                        <select
                            className="form-select"
                            value={student['20.12 (2семинар)']}
                            onChange={(e) => handleStatusChange(student.id, '20.12 (2семинар)', e.target.value)}
                        >
                            <option value="Нет">Отсутствовал</option>
                            <option value="Оп">Опоздал</option>
                            <option value="Был">Присутствовал</option>
                        </select>
                    </td>
                    <td>
                        <div className="form-check">
                            <input
                                type="checkbox"
                                className="form-check-input"
                                id={`checkbox-${student.id}`}
                                checked={student.selected}
                                onChange={() => toggleSelection(student.id)}
                            />
                            <label className="form-check-label" htmlFor={`checkbox-${student.id}`}>
                                Выбрать
                            </label>
                        </div>
                    </td>
                    <td>
                        <select
                            className="form-select"
                            value={student.points}
                            onChange={(e) => handlePointsChange(student.id, e.target.value)}
                        >
                            {Array.from({ length: 21 }, (_, index) => (
                                <option key={index} value={index}>
                                    {index}
                                </option>
                            ))}
                        </select>
                    </td>
                    <td>
                        <button className="btn btn-danger" onClick={() => removeStudent(student.id)}>
                            Удалить
                        </button>
                    </td>
                </tr>
            ))}
            </tbody>
        </table>
    );
};

export default StudentsTable;
