import React, { useState } from 'react';

const AddStudentForm = ({ addStudent }) => {
    const [newStudentName, setNewStudentName] = useState('');
    const handleInputChange = (event) => {
        setNewStudentName(event.target.value);
    };
    const handleAddStudent = () => {
        if (newStudentName.trim() !== '') {
            addStudent(newStudentName);
            setNewStudentName('');
        }
    };


    return (
        <div className="input-group mb-3">
            <input
                type="text"
                id="newStudentInput"
                className="form-control"
                placeholder="Введите ФИО студента, которого хотите добавить"
                value={newStudentName}
                onChange={handleInputChange}
            />
            <div className="input-group-append">
                <button className="btn btn-primary" onClick={handleAddStudent}>
                    Добавить
                </button>
            </div>
        </div>
    );
};
export default AddStudentForm;
