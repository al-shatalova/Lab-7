const initialStudents = [
    { id: '1', name: 'Парамонов Д.В', points: 17, selected: false },
    { id: '2', name: 'Перов А.В.', points: 17, selected: false },
    { id: '3', name: 'Миронов С.И.', points: 17, selected: false },
    { id: '4', name: 'Белявский Г.И.', points: 3, selected: false },
];

export default initialStudents;
