import React, { useState } from 'react';
import initialStudents from './initialStudents';
import AddStudentForm from './AddStudentForm';
import FilterSelect from './FilterSelect';
import StudentsTable from './StudentsTable';
import {Link} from "react-router-dom";


const Students = () => {
    const [students, setStudents] = useState(initialStudents);
    const [filter, setFilter] = useState('all');
    const [sortOrder, setSortOrder] = useState('desc');

    const handlePointsChange = (id, value) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === id ? { ...student, points: value } : student
            )
        );
    };

    const sortByPoints = () => {
        const newSortOrder = sortOrder === 'desc' ? 'asc' : 'desc';
        setSortOrder(newSortOrder);

        const sortedStudents = [...students].sort((a, b) => {
            if (newSortOrder === 'asc') {
                return a.points - b.points;
            } else {
                return b.points - a.points;
            }
        });

        setStudents(sortedStudents);
    };


    const addStudent = (name) => {
        const newStudent = { id: Date.now().toString(), name, selected: false };
        setStudents((prevStudents) => [...prevStudents, newStudent]);
    };

    const toggleSelection = (id) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === id ? { ...student, selected: !student.selected } : student
            )
        );
    };

    const removeStudent = (id) => {
        setStudents((prevStudents) => prevStudents.filter((student) => student.id !== id));
    };

    const handleStatusChange = (id, date, status) => {
        setStudents((prevStudents) =>
            prevStudents.map((student) =>
                student.id === id ? { ...student, [date]: status } : student
            )
        );
    };

    const handleFilterChange = (event) => {
        setFilter(event.target.value);
    };

    const filteredStudents = students.filter((student) => {
        if (filter === 'all') {
            return true;
        } else if (filter === 'selected') {
            return student.selected;
        } else {
            return !student.selected;
        }
    });

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <i className="fas fa-bars"></i>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <header className="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-light">
                            <Link to="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                                <svg className="bi me-2" width="40" height="32">
                                    <use xlinkHref="#bootstrap"></use>
                                </svg>
                                <span className="fs-4">FinWave</span>
                            </Link>
                            <ul className="nav nav-pills">
                                <li className="nav-item"><a href="/disciplines" className="nav-link text-dark">Дисциплины</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Расписание</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Учебный процесс</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark"></a></li>
                            </ul>
                        </header>
                    </div>
                </div>
            </nav>
        <div className="container mt-4 text-center">
            <h1>Журнал посещаемости ПИ21-3</h1>

            <FilterSelect filter={filter} handleFilterChange={handleFilterChange} />

            <StudentsTable
                filteredStudents={filteredStudents}
                handleStatusChange={handleStatusChange}
                toggleSelection={toggleSelection}
                removeStudent={removeStudent}
                handlePointsChange={handlePointsChange}
                sortByPoints={sortByPoints}
            />

            <div>
                <AddStudentForm addStudent={addStudent} />
            </div>
        </div>
        </div>
    );
};

export default Students;
