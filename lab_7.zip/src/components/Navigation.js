import React from 'react';

const Navigation = () => {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <i className="fas fa-bars"></i>
                    </button>

                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <header className="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-light">
                            <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                                <svg className="bi me-2" width="40" height="32">
                                    <use xlinkHref="#bootstrap"></use>
                                </svg>
                                <span className="fs-4">FinWave</span>
                            </a>
                            <ul className="nav nav-pills">
                                <li className="nav-item"><a href="/disciplines" className="nav-link text-dark">Дисциплины</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Расписание</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Учебный процесс</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark"></a></li>
                            </ul>
                        </header>
                    </div>
                </div>
            </nav>
        </div>
    );
};

export default Navigation;
