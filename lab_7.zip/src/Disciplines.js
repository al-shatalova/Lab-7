import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from "react-router-dom";

const disciplinesData = {
    'Глубокое обучение': 'Описание глубокого обучения...',
    'ОВП': 'Описание ОВП...',
};

function DisciplinesPage() {
    const [selectedDiscipline, setSelectedDiscipline] = useState('Глубокое обучение');

    const handleDisciplineClick = (discipline) => {
        setSelectedDiscipline(discipline);
    };

    return (
        <>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <i className="fas fa-bars"></i>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <header className="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-light">
                            <Link to="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                                <svg className="bi me-2" width="40" height="32">
                                    <use xlinkHref="#bootstrap"></use>
                                </svg>
                                <span className="fs-4">FinWave</span>
                            </Link>
                            <ul className="nav nav-pills">
                                <li className="nav-item"><a href="/disciplines" className="nav-link text-dark">Дисциплины</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Расписание</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark">Учебный процесс</a></li>
                                <li className="nav-item"><a href="/" className="nav-link text-dark"></a></li>
                            </ul>
                        </header>
                    </div>
                </div>
            </nav>
        <div className="container">
            <div className="row mt-5">
                <div className="col-md-6 offset-md-3">
                    <h1 className="text-center mb-4">Выберите дисциплину</h1>
                    <ul className="list-group">
                        {Object.keys(disciplinesData).map((discipline) => (
                            <li
                                key={discipline}
                                className={`list-group-item ${selectedDiscipline === discipline ? 'active' : ''}`}
                                onClick={() => handleDisciplineClick(discipline)}
                            >
                                {discipline}
                            </li>
                        ))}
                    </ul>
                    {selectedDiscipline && (
                        <div className="mt-4">
                            <h2 className="text-center">{selectedDiscipline}</h2>
                            <p>{disciplinesData[selectedDiscipline]}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
            </>
    );
}

export default DisciplinesPage;
