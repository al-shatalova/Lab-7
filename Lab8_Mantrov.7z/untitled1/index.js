import React, { useState } from 'react';

// Новостной слайдер
function NewsSlider({ articles, currentArticle, onArticleChange }) {
  return (
    <div>
      <h2>Programming News</h2>
      <button onClick={() => onArticleChange(currentArticle - 1)} disabled={currentArticle === 0}>
        Previous
      </button>
      <p>{articles[currentArticle]}</p>
      <button onClick={() => onArticleChange(currentArticle + 1)} disabled={currentArticle === articles.length - 1}>
        Next
      </button>
    </div>
  );
}

// Таймер отдыха
function BreakTimer({ minutes, onTimerStart, onTimerReset }) {
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);

  const toggleTimer = () => {
    if (isActive) {
      clearInterval(interval);
    } else {
      const interval = setInterval(() => {
        if (seconds === 0) {
          clearInterval(interval);
          onTimerReset();
        } else {
          setSeconds((prevSeconds) => prevSeconds - 1);
        }
      }, 1000);
    }

    setIsActive(!isActive);
  };

  return (
    <div>
      <h2>Break Timer</h2>
      <p>{`${minutes}:${seconds < 10 ? `0${seconds}` : seconds}`}</p>
      <button onClick={toggleTimer}>{isActive ? 'Pause' : 'Start'}</button>
    </div>
  );
}

// Главный компонент
export default function ProgrammingNewsMedia() {
  const [newsArticles, setNewsArticles] = useState([
    'New JavaScript Framework Released!',
    'Top 10 Programming Languages in 2023',
    'How to Master Git: A Developer\'s Guide',
  ]);

  const [currentArticle, setCurrentArticle] = useState(0);

  const handleArticleChange = (index) => {
    setCurrentArticle(index);
  };

  const handleTimerReset = () => {
    // Логика сброса таймера
  };

  return (
    <div>
      <h1>Programming News Media</h1>
      <NewsSlider articles={newsArticles} currentArticle={currentArticle} onArticleChange={handleArticleChange} />
      <BreakTimer minutes={5} onTimerReset={handleTimerReset} />
    </div>
  );
}
