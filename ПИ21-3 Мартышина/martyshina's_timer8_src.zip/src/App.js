import React, { useState, useRef, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Navigation = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <i className="fas fa-bars"></i>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <a className="navbar-brand mt-2 mt-lg-0" href="/">
              Новости
            </a>
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="navbar-nav">
                <a className="nav-link">
                  Информация
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};


const Timer = ({ onTimerStart, onTimerStop }) => {
  const [startTime, setStartTime] = useState(null);
  const [now, setNow] = useState(null);
  const [timerRunning, setTimerRunning] = useState(false);
  const intervalRef = useRef(null);

  const handleStart = () => {
    setStartTime(Date.now());
    setNow(Date.now());
    clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setNow(Date.now());
    }, 10);
    setTimerRunning(true);
    onTimerStart();
  };

  const handleStop = () => {
    clearInterval(intervalRef.current);
    setTimerRunning(false);
    onTimerStop();
  };

  let secondsPassed = 0;
  if (startTime && now != null) {
    secondsPassed = (now - startTime) / 1000;
  }

  useEffect(() => {
    return () => {
      clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div style={{display: 'flex'}}>
      <h2>Таймер: {secondsPassed.toFixed(3)}</h2>
      <button
        onClick={timerRunning ? handleStop : handleStart}
        style={{
          marginLeft: '10px',
          padding: '3px 10px',
          fontSize: '20px',
          backgroundColor: 'black',
          color: 'white',
          border: 'none',
          borderRadius: '10px',
        }}
      >
        {timerRunning ? 'Стоп' : 'Старт'}
      </button>
    </div>
  );
};

const Slider = ({ timerRunning }) => {
  const [currentArticle, setCurrentArticle] = useState(1);
  const sliderRef = useRef(null); // Создаем ссылку для элемента слайдера

  // Обновленная логика для учета состояния таймера
  const handleNext = () => {
    if (!timerRunning) {
      setCurrentArticle((prevArticle) => prevArticle + 1);
    }
  };

  const handlePrev = () => {
    if (!timerRunning) {
      setCurrentArticle((prevArticle) => Math.max(1, prevArticle - 1));
    }
  };

  useEffect(() => {
    // манипуляции с DOM
    const sliderElement = sliderRef.current;
  
    if (sliderElement) {
      sliderElement.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentArticle, sliderRef]);

  const articles = [
    {
      title: "10 основных принципов веб-дизайна для потрясающего сайта",
      content:
        "Узнайте основные принципы, делающие веб-сайт визуально привлекательным и эффективным, от композиции и цвета до типографики и изображений. Поднимите свои навыки веб-дизайна для создания потрясающих пользовательских впечатлений. Исследования показывают, что основные принципы веб-дизайна для создания потрясающего сайта включают в себя следующее: Согласованность - все элементы сайта должны быть согласованы между собой. Ясность и простота - сайт должен быть понятным и легким в использовании. Цветовая гамма- правильно подобранные цвета могут значительно повысить привлекательность сайта. Хорошая навигация - пользователи должны легко находить нужную информацию. Адаптивный дизайн- сайт должен хорошо отображаться на различных устройствах.Быстрая загрузка- время загрузки сайта важно для удобства пользователей. Четкая типографика- правильно подобранные шрифты и их размеры влияют на удобство чтения. Использование пространства- правильное использование отступов и пространства делает сайт более приятным для глаз. Качественные изображения- визуальный контент играет важную роль в создании привлекательного сайта.Тестирование и оптимизация- постоянное тестирование и оптимизация сайта помогают улучшить пользовательский опыт. Исходя из этого, следует уделить внимание этим принципам при создании веб-сайта для достижения потрясающих результатов.",
    },
    {
      title: "Важность отзывчивого дизайна в современной веб-разработке",
      content:
        "Исследуйте значение отзывчивого дизайна в современном цифровом мире. Поймите, как отзывчивый дизайн обеспечивает беспроблемные пользовательские впечатления на различных устройствах, от настольных компьютеров до смартфонов, и его влияние на вовлеченность и удержание пользователей. Отзывчивый дизайн играет ключевую роль в современной веб-разработке, поскольку обеспечивает оптимальное отображение веб-сайта на различных устройствах, включая настольные компьютеры, планшеты и смартфоны. Это позволяет пользователям получать одинаково качественный пользовательский опыт независимо от устройства, которое они используют для доступа к сайту. Отзывчивый дизайн также способствует удержанию пользователей, поскольку обеспечивает беспрепятственный доступ к контенту и функциональности сайта, что в свою очередь повышает удовлетворенность пользователей и их вовлеченность. Таким образом, понимание и умение реализовывать отзывчивый дизайн в веб-разработке становится все более важным в современном цифровом мире, где мобильные устройства играют все более значимую роль в повседневной жизни пользователей.",
    },
    {
      title: "Теория цвета в веб-дизайне: создание визуально привлекательных сайтов",
      content:
        "Погрузитесь в мир теории цвета и ее применения в веб-дизайне. Узнайте, как выбирать цветовые схемы, вызывающие определенные эмоции, улучшают читаемость и создают визуально привлекательные сайты, которые оставляют незабываемое впечатление. Когда дело доходит до веб-дизайна, теория цвета играет важную роль в создании привлекательных и эффективных сайтов. Выбор правильных цветовых схем не только способствует улучшению читаемости, но и создает определенные эмоциональные реакции у посетителей. Погружаясь в мир теории цвета, дизайнеры могут создавать сайты, которые не только информативны, но и визуально привлекательны, оставляя незабываемое впечатление на пользователей.",
    },
    {
      title: "Искусство минимализма в веб-дизайне: менее значит больше",
      content:
        "Примите принципы минимализма в веб-дизайне и узнайте, как простота может привести к мощным пользовательским впечатлениям. Научитесь освобождать свои дизайны от лишних элементов, сосредотачиваться на ключевых аспектах и создавать элегантные и функциональные веб-сайты.",
    },
  ];
  
  return (
    <div className="article-container" style={{ width: '70%', margin: '20px auto' }}>
{/* 
    <h2>Статья №{currentArticle}: {articles[currentArticle - 1].title}</h2>
    <p>{articles[currentArticle - 1].content}</p> */}
    <div ref={sliderRef}>
        <h2>Статья №{currentArticle}: {articles[currentArticle - 1].title}</h2>
        <p>{articles[currentArticle - 1].content}</p>
    </div>
      <button
        onClick={handlePrev}
        style={{
          marginLeft: '10px',
          padding: '3px 10px',
          fontSize: '20px',
          backgroundColor: 'black',
          color: 'white',
          border: 'none',
          borderRadius: '10px',
        }}
      >
        Предыдущая статья
      </button>
      <button
        onClick={handleNext}
        style={{
          marginLeft: '10px',
          padding: '3px 10px',
          fontSize: '20px',
          backgroundColor: 'black',
          color: 'white',
          border: 'none',
          borderRadius: '10px',
        }}
      >
        Следующая статья
      </button>
    </div>
  );
};

const App = () => {
  const [timerRunning, setTimerRunning] = useState(false);

  const handleTimerStart = () => {
    setTimerRunning(true);
  };

  const handleTimerStop = () => {
    setTimerRunning(false);
  };

  return (
    <div className="main-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <Navigation />
      <Timer onTimerStart={handleTimerStart} onTimerStop={handleTimerStop} />
      <Slider timerRunning={timerRunning} />
    </div>
  );
};

export default App;
