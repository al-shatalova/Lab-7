import React, { useState, useRef, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Navigation = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <i className="fas fa-bars"></i>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <a className="navbar-brand mt-2 mt-lg-0" href="/">
              QUIZ
            </a>
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="navbar-nav">
                <a className="nav-link">
                  Info
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};

const App = () => {
  const questions = [
    {
      id: 1,
      text: 'Что такое React?',
      options: ['JavaScript библиотека', 'JavaScript фреймворк', 'Препроцессор CSS'],
      correctOption: 'JavaScript библиотека',
    },
    {
      id: 2,
      text: 'Что такое JSX?',
      options: ['JavaScript Syntax Extension', 'JavaScript XML', 'JavaScript XML Syntax'],
      correctOption: 'JavaScript XML Syntax',
    },
    {
      id: 3,
      text: 'React в основном используется для...',
      options: ['Базы данных', 'Разработки платформы', 'Создания интерактивных пользовательских интерфейсов в веб- и мобильных приложениях'],
      correctOption: 'Создания интерактивных пользовательских интерфейсов в веб- и мобильных приложениях',
    },
  ];
  // Декларативный подход в React подразумевает описание, как должен выглядеть пользовательский интерфейс 
  // в зависимости от состояния, не вдаваясь в детали того, как достичь этого состояния. 
  // Это позволяет разработчикам фокусироваться на том, 
  // что должно быть на странице, а не на том, как это должно быть достигнуто.

  const [userAnswers, setUserAnswers] = useState({});
  const [currentQuestion, setCurrentQuestion] = useState(0);

  // декларативный способ обновления данных
  const handleOptionSelect = (questionId, selectedOption) => {
    // (handleOptionSelect) обновляет состояние (userAnswers) с использованием функции setUserAnswers
    setUserAnswers((prevAnswers) => ({ ...prevAnswers, [questionId]: selectedOption }));
  };

  // handleOptionSelect и handleNext декларативно обновляют состояние userAnswers и currentQuestion, 
  // используя функциональные формы setState. 
  const handleNext = () => {
    setCurrentQuestion((prevQuestion) => prevQuestion + 1);
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((question) => {
      const userAnswer = userAnswers[question.id];
      if (userAnswer === question.correctOption) {
        score++;
      }
    });
    return score;
  };

  return (
    <div className="main-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <Navigation />
      {/* Использование тернарного оператора {condition ? true : false} 
      для декларативного отображения компонента в зависимости от значения currentQuestion */}
      {currentQuestion < questions.length ? (
        <>
          <h2>Вопрос {currentQuestion + 1}:</h2>
          <p style={{fontSize: '30px', fontWeight: 'bold'}}>{questions[currentQuestion].text}</p>
          <ul>
            {questions[currentQuestion].options.map((option, index) => (
              <li key={index}>
                <label style={{fontSize: '20px'}}>
                  <input
                    type="radio"
                    name={`question-${currentQuestion}`}
                    value={option}
                    onChange={() => handleOptionSelect(questions[currentQuestion].id, option)}
                    checked={userAnswers[questions[currentQuestion].id] === option}
                  />
                  {option}
                </label>
              </li>
            ))}
          </ul>
          <button style={{
          marginLeft: '10px',
          padding: '3px 10px',
          fontSize: '20px',
          backgroundColor: 'black',
          color: 'white',
          border: 'none',
          borderRadius: '10px',
        }} 
        onClick={handleNext}>Следующий вопрос</button>
        </>
      ) : (
        <>
          <h2>Квиз завершен!</h2>
          <p style={{fontSize: '30px'}}>Ваш результат: {calculateScore()} из {questions.length}</p>
        </>
      )}
    </div>
  );
};


export default App;
