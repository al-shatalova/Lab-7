import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import AddPage from './components/AddPage';
import News from "./components/News";

const App = () => {
    return (
        <Router>
            <div>
                <Header />
                <Routes>
                    <Route path="/info" element={<AddPage />} />
                    <Route path="/blog" element={<News />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
