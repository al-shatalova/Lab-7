import React, {useState} from 'react';
import Timer from "./Timer";
import BlogSlider from "./BlogSlider";
import BlogToggler from "./BlogToggler";
import {Button} from "react-bootstrap";

const News = () => {
    const [desc, setDesc] = useState(true)
    return (
        <div>
            <Timer />
            {desc ? (
                <center><Button onClick={() => setDesc(!desc)}>Скрыть описание</Button></center>
            ):(
                <center><Button onClick={() => setDesc(!desc)}>Отображение описания</Button></center>
            )}

            <BlogSlider desc = {desc}/>
            <BlogToggler />
        </div>
    );
};

export default News;