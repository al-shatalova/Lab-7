import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Header = () => {
    return (
        <header className="border-bottom lh-1 py-3">
            <ul className="row flex-nowrap justify-content-between align-items-center">
                <div className="col-4 text-center">
                    <a className="blog-header-logo text-body-emphasis text-decoration-none" href="#" > <h1>ФИНАНСОВЫЙ УНИВЕРСИТЕТ</h1></a>
                </div>
                <div className="col-4 d-flex justify-content-end align-items-center">
                    <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                        <Link className="nav-item nav-link link-body-emphasis active" to="/">
                            <h6>Вся группа</h6>
                        </Link>
                        <Link className="nav-item nav-link link-body-emphasis" to="/cart">
                            <h6>Журнал посещаемости</h6>

                        </Link>

                        <a className="nav-item nav-link link-body-emphasis" href="#"><h6>Войти</h6></a>
                    </ul>
                </div>
            </ul>
        </header>
    );
};

export default Header;
