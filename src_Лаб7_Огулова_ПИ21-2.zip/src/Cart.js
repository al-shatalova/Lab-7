import React, { useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import {Link} from "react-router-dom";

const Cart = ({ cartItems, updateQuantity}) => {
    const [searchName, setSearchName] = useState('');

    const handleUpdateQuantity = (productId, newQuantity) => {
        updateQuantity(productId, newQuantity);
    };


    const handleRemoveFromCart = (productId) => {
        updateQuantity(productId, 0);
    };
    const filteredCartItems = cartItems.filter((item) =>
        item.name.toLowerCase().includes(searchName.toLowerCase())
    );

    return (

        <div className="container mt-5">


            <br/>

            <div className="input-group rounded">
                <input type="search" className="form-control rounded" placeholder="Поиск" aria-label="Search"
                       aria-describedby="search-addon" value={searchName}
                       onChange={(e) => setSearchName(e.target.value)}/>

            </div>
            <br/>
            <Table striped bordered hover>
                <thead>
                <tr>
                    <th>#</th>
                    <th>Студент</th>
                    <th>Количество посещений</th>
                    <th>01.12</th>
                    <th>02.12</th>
                    <th>03.12</th>
                    <th>Сумма баллов</th>
                </tr>
                </thead>
                <tbody>
                {filteredCartItems.map((item, index) => (
                    <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{item.name}</td>
                        <td>

                            {item.quantity}{' '}

                        </td>
                        <td>
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                            >
                                -
                            </Button>{' '}
                            {item.quantity}{' '}
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                            >
                                +
                            </Button>
                        </td>
                        <td>
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                            >
                                -
                            </Button>{' '}
                            {item.quantity}{' '}
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                            >
                                +
                            </Button>
                        </td>
                        <td>
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                            >
                                -
                            </Button>{' '}
                            {item.quantity}{' '}
                            <Button
                                variant="light"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                            >
                                +
                            </Button>
                        </td>
                        {/*<td>{item.price}</td>*/}
                        <td>{item.quantity * item.price}</td>
                        <td>
                            <Button variant="danger" size="sm" onClick={() => handleRemoveFromCart(item.id)}>
                                Удалить
                            </Button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </Table>
            {/*)}*/}
            {/*<Button variant="success">Оформить заказ</Button>*/}
        </div>
    );
};

export default Cart;
