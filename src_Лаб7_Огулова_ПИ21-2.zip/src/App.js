import React, { useState, useEffect } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Menu from './Menu';
import Header from './Header';
import ProductDetail from './ProductDetail';
import Cart from './Cart';
// import 'bootstrap/dist/css/bootstrap.min.css';
const products = [
  {
    id: 1,
    name: 'Абдулаев Муса Исрапилович',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/70056/25001.281474976805566_optimized.jpg',
    prev_price: 255,
    quantity: 0
  },
  {
    id: 2,
    name: 'Арясин Никита Анатольевич',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    ingredients: 'Информационных технологий и анализа больших данных',
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/68973/25001.281474976809348_optimized.jpg',
    prev_price: 1173,
    quantity: 0
  },
  {
    id: 3,
    name: 'Битулев Валерий Геннадьевич',
    price: 2,
    description: 'Энзимная пудра для умывания с энзимами папайи для всех типов кожи. Энзимная пудра разработана для глубокого очищения кожи от излишков себума, омертвевших клеток, пыли и остатков косметических средств.',
    features: ["213756"],
    ingredients: 'Информационных технологий и анализа больших данных',
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/65008/25001.281474976806315_optimized.jpg',
    prev_price: 1400,
    quantity: 0
  },
  {
    id: 4,
    name: 'Васильева Алина Андреевна',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67028/25001.281474976810673_optimized.jpg',
    prev_price: 13900,
    quantity: 0
  },
  {
    id: 5,
    name: 'Горностаев Дмитрий Андреевич',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/64951/25001.281474976809157_optimized.jpg',
    prev_price: 1002,
    quantity: 0
  },
  {
    id: 6,
    name: 'Егорова Ева Евгеньевна',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/70144/25001.281474976808029_optimized.jpg',
    prev_price: 11620,
    quantity: 0
  },
  {
    id: 7,
    name: 'Журавлева Анастасия Олеговна',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67163/25001.281474976809979_optimized.jpg',
    prev_price: 991,
    quantity: 0
  },
  {
    id: 8,
    name: 'Исупова Дарья Евгеньевна',
    price: 2,
    description: 'Информационных технологий и анализа больших данных',
    features: ["213756"],
    ingredients: 'Рикотта, сливки, яйца, сахар',
    image: 'https://org.fa.ru/bitrix/galaktika/galaktika.vuzapi/public/files/users/67451/25001.281474976808490_optimized.jpg',
    prev_price: 550,
    quantity: 0
  },

];

const App = () => {
  const [cartItems, setCartItems] = React.useState([]);

  useEffect(() => {
    setCartItems(products)
  }, [])


  const addToCart = (product) => {
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      const updatedCart = cartItems.map((item) =>
          item.id === existingItem.id ? { ...item, quantity: item.quantity + 1} : item
      );
      setCartItems(updatedCart);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1}]);
    }

  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity < 0) return
    const updatedCart = cartItems.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCart);
  };

  return (
      <div>
        <Header />
        <Routes>
          <Route path="/" element={<Menu menuItems={products} />} />
          <Route
              path="/product/:id"
              element={<ProductDetail products={products} addToCart={addToCart} />}
          />
          <Route path="/cart" element={<Cart cartItems={cartItems} addToCart={addToCart} updateQuantity={updateQuantity}/>} />
        </Routes>

      </div>
  );
};

export default App;
