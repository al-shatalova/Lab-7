export const data = [
  { id: 1, name: "Анастасия Журавлева", score: "100", dates: [] },
  { id: 2, name: "Валерий Битулев", score: "51", dates: [] },
  { id: 3, name: "Алексей Рязанцев", score: "51", dates: [] },
  { id: 4, name: "Никита Арясин", score: "60", dates: [] },
];
