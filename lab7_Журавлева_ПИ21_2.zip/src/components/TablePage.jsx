import { Table } from "./Table";

export const TablePage = () => {
  return (
    <div>
      <Table />;
    </div>
  );
};
