export const MainPage = () => {
  return (
    <>
      <ul class="list-group">
        <li class="list-group-item active" aria-current="true">
          Дисциплины
        </li>
        <li class="list-group-item">Алгебра и анализ</li>
        <li class="list-group-item">Философия</li>
        <li class="list-group-item">Веб-разработка</li>
        <li class="list-group-item">Глубокое обучение</li>
      </ul>
    </>
  );
};
