import { Outlet } from "react-router-dom";
import { TopNavBar } from "./TopNavBar";

export const PageWrapper = () => {
  return (
    <>
      <TopNavBar />
      <Outlet />
    </>
  );
};
