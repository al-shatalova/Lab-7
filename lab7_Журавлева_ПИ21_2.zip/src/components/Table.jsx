import React, { useState } from "react";
import { data } from "../data";

let nextId = 5;

export function Table({}) {
  const [name, setName] = useState("");
  const [score, setScore] = useState("");
  const [filter, setFilter] = useState("");
  const [students, setStudents] = useState(data);

  const addStudent = () => {
    setStudents([...students, { id: nextId++, name: name, score: score }]);
    setName("");
    setScore("");
  };

  const deleteStudent = (id) => {
    setStudents(students.filter((student) => student.id !== id));
  };

  const filterStudents = () => {
    if (filter === "") {
      setStudents(data);
    } else {
      setStudents(students.filter((student) => student.score === filter));
    }
  };

  const sortStudents = () => {
    const sortedList = [...students];
    sortedList.sort((a, b) => a.score - b.score);
    setStudents(sortedList);
  };

  return (
    <div>
      <div className="btn-group">
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Балл для фильтрации"
        />
        <button className="btn btn-dark btn-sm" onClick={filterStudents}>
          Отфильтровать по баллам
        </button>
        <button className="btn btn-dark btn-sm" onClick={sortStudents}>
          Сортировать по баллам
        </button>
      </div>
      <table className="table table-striped">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">Имя</th>
            <th scope="col">Балл</th>
            <th scope="col">07.12</th>
            <th scope="col">08.12</th>
            <th scope="col">09.12</th>
            <th scope="col">10.12</th>
            <th scope="col">Действия</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <th scope="row">{student.id}</th>
              <td>{student.name}</td>
              <td>{student.score}</td>
              <td>
                <select className="form-select">
                  <option selected></option>
                  <option value="1">п</option>
                  <option value="2">оп</option>
                  <option value="3">н</option>
                </select>
              </td>
              <td>
                <select class="form-select">
                  <option selected></option>
                  <option value="1">п</option>
                  <option value="2">оп</option>
                  <option value="3">н</option>
                </select>
              </td>
              <td>
                <select class="form-select">
                  <option selected></option>
                  <option value="1">п</option>
                  <option value="2">оп</option>
                  <option value="3">н</option>
                </select>
              </td>
              <td>
                <select class="form-select">
                  <option selected></option>
                  <option value="1">п</option>
                  <option value="2">оп</option>
                  <option value="3">н</option>
                </select>
              </td>
              <td>
                <button
                  className="btn btn-dark btn-sm"
                  onClick={() => deleteStudent(student.id)}
                >
                  Удалить
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="btn-group">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="ФИО"
        />
        <input
          value={score}
          onChange={(e) => setScore(e.target.value)}
          placeholder="Балл"
        />
        <button className="btn btn-dark btn-sm" onClick={addStudent}>
          {"Добавить студента"}
        </button>
      </div>
    </div>
  );
}
