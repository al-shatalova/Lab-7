import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import { MainPage } from "./components/MainPage";
import { PageWrapper } from "./components/PageWrapper";
import { MealPage, TablePage } from "./components/TablePage";

function App() {
  return (
    <BrowserRouter basename="/">
      <Routes>
        <Route path="/" element={<PageWrapper />}>
          <Route index element={<MainPage />} />
          <Route path="table/" element={<TablePage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
